-- PostgreSQL / SQLite compatible schema for OmayRaa-Akhi Screen Lock Backend

CREATE TABLE IF NOT EXISTS Admins (
    admin_id TEXT PRIMARY KEY,
    role TEXT NOT NULL DEFAULT 'SUPER_ADMIN',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Devices (
    device_id TEXT PRIMARY KEY,
    device_name TEXT NOT NULL,
    enrollment_status TEXT NOT NULL DEFAULT 'ENROLLED',
    connection_status TEXT NOT NULL DEFAULT 'OFFLINE',
    lock_status TEXT NOT NULL DEFAULT 'UNLOCKED',
    registered_at TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    token_hash TEXT NOT NULL,
    permissions_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS AppConfiguration (
    id INTEGER PRIMARY KEY,
    website_url TEXT NOT NULL,
    lock_image_url TEXT NOT NULL DEFAULT '',
    unlock_instructions TEXT NOT NULL,
    configuration_version INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Security (
    device_id TEXT PRIMARY KEY,
    pin_hash TEXT NOT NULL,
    pin_updated_at TEXT NOT NULL,
    recovery_configuration TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS ActivityLogs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    event_timestamp TEXT NOT NULL,
    administrator_id TEXT,
    details TEXT
);
