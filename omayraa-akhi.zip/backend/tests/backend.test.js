import test from "node:test";
import assert from "node:assert/strict";
import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import { createApp } from "../src/server.js";
import { verifyPin } from "../src/security.js";

async function startTestServer() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "omayraa-test-"));
  const sentMessages = [];
  const fakeFetch = async (url, options) => {
    if (options?.body) {
      sentMessages.push({ url, body: JSON.parse(options.body) });
    }
    return {
      ok: true,
      async json() {
        return { ok: true, result: { message_id: 99 } };
      }
    };
  };

  const { app, db } = await createApp(
    {
      SQLITE_PATH: ":memory:",
      UPLOADS_DIR: tmpDir,
      ADMIN_TELEGRAM_ID: "777001",
      TELEGRAM_BOT_TOKEN: "test-bot-token",
      TELEGRAM_WEBHOOK_SECRET: "secret-hook-token",
      DEFAULT_WEBSITE_URL: "https://initial.example.com",
      DEFAULT_LOCK_PIN: "4321"
    },
    { fetchImpl: fakeFetch }
  );

  const server = await new Promise((resolve) => {
    const s = app.listen(0, "127.0.0.1", () => resolve(s));
  });
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  return {
    baseUrl,
    db,
    sentMessages,
    async cleanup() {
      await new Promise((resolve) => server.close(resolve));
      await db.close();
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  };
}

test("device registration, config sync, PIN hash verification, and recovery flow", async () => {
  const ctx = await startTestServer();
  try {
    const regRes = await fetch(`${ctx.baseUrl}/api/devices/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: "android-dev-1",
        device_name: "Pixel 9",
        permissions: { INTERNET: true, POST_NOTIFICATIONS: false }
      })
    });
    assert.equal(regRes.status, 200);
    const regJson = await regRes.json();
    assert.equal(regJson.device_id, "android-dev-1");
    assert.ok(regJson.device_token.length >= 32);
    assert.equal(regJson.config.website_url, "https://initial.example.com");
    assert.ok(verifyPin("4321", regJson.config.pin_hash));

    // Unauthorized sync without token fails
    const unauthRes = await fetch(`${ctx.baseUrl}/api/devices/android-dev-1/sync`);
    assert.equal(unauthRes.status, 401);

    // Authorized sync succeeds
    const syncRes = await fetch(`${ctx.baseUrl}/api/devices/android-dev-1/sync`, {
      headers: { Authorization: `Bearer ${regJson.device_token}` }
    });
    assert.equal(syncRes.status, 200);
    const syncJson = await syncRes.json();
    assert.equal(syncJson.enrollment_status, "ENROLLED");
  } finally {
    await ctx.cleanup();
  }
});

test("Telegram webhook enforces secret token and ADMIN_TELEGRAM_ID authorization", async () => {
  const ctx = await startTestServer();
  try {
    // Missing webhook secret rejected
    const badHook = await fetch(`${ctx.baseUrl}/api/telegram/webhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: { chat: { id: 999 }, from: { id: 999 }, text: "/start" } })
    });
    assert.equal(badHook.status, 403);

    // Unauthorized Telegram user gets access denied
    const unauthUserHook = await fetch(`${ctx.baseUrl}/api/telegram/webhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": "secret-hook-token"
      },
      body: JSON.stringify({ message: { chat: { id: 999 }, from: { id: 999 }, text: "/start" } })
    });
    assert.equal(unauthUserHook.status, 200);
    assert.ok(ctx.sentMessages.some((m) => m.body.text?.includes("Access denied")));

    // Authorized admin updates Website URL via interactive Telegram callback + message
    await fetch(`${ctx.baseUrl}/api/telegram/webhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": "secret-hook-token"
      },
      body: JSON.stringify({
        callback_query: {
          id: "cb1",
          from: { id: 777001 },
          message: { chat: { id: 777001 } },
          data: "menu:update_url"
        }
      })
    });

    await fetch(`${ctx.baseUrl}/api/telegram/webhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": "secret-hook-token"
      },
      body: JSON.stringify({
        message: {
          message_id: 10,
          chat: { id: 777001 },
          from: { id: 777001 },
          text: "https://updated.example.org"
        }
      })
    });

    const cfg = await ctx.db.getGlobalConfig();
    assert.equal(cfg.website_url, "https://updated.example.org");
    assert.equal(cfg.configuration_version, 2);
  } finally {
    await ctx.cleanup();
  }
});

test("Telegram admin can issue and device can consume one-time emergency recovery code", async () => {
  const ctx = await startTestServer();
  try {
    const regRes = await fetch(`${ctx.baseUrl}/api/devices/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ device_id: "dev-rec-1", device_name: "Tablet" })
    });
    const { device_token: token } = await regRes.json();

    await fetch(`${ctx.baseUrl}/api/telegram/webhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token": "secret-hook-token"
      },
      body: JSON.stringify({
        callback_query: {
          id: "cb2",
          from: { id: 777001 },
          message: { chat: { id: 777001 } },
          data: "rec:issue:dev-rec-1"
        }
      })
    });

    const issuedMsg = ctx.sentMessages.find((m) => m.body.text?.includes("Code: "));
    assert.ok(issuedMsg);
    const match = issuedMsg.body.text.match(/Code:\s*([A-Z0-9]{8})/);
    assert.ok(match);
    const code = match[1];

    const verifyRes = await fetch(`${ctx.baseUrl}/api/devices/dev-rec-1/recovery/verify`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ recovery_code: code })
    });
    const verifyJson = await verifyRes.json();
    assert.equal(verifyJson.valid, true);

    // Code cannot be reused
    const reuseRes = await fetch(`${ctx.baseUrl}/api/devices/dev-rec-1/recovery/verify`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ recovery_code: code })
    });
    const reuseJson = await reuseRes.json();
    assert.equal(reuseJson.valid, false);
  } finally {
    await ctx.cleanup();
  }
});
