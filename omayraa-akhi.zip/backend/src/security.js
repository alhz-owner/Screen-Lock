import crypto from "node:crypto";

const PIN_PREFIX = "pbkdf2_sha256";
const DEFAULT_ITERATIONS = 100_000;
const SALT_BYTES = 16;
const KEY_BYTES = 32;

/**
 * Hashes a PIN using PBKDF2-HMAC-SHA256 in the exact wire format verified by Android PinHasher.kt:
 *   pbkdf2_sha256$<iterations>$<saltHex>$<derivedKeyHex>
 */
export function hashPin(pin, iterations = DEFAULT_ITERATIONS) {
  if (!isValidPin(pin)) {
    throw new Error("PIN must be 4 to 12 numeric digits.");
  }
  const salt = crypto.randomBytes(SALT_BYTES);
  const derived = crypto.pbkdf2Sync(Buffer.from(pin, "utf8"), salt, iterations, KEY_BYTES, "sha256");
  return `${PIN_PREFIX}$${iterations}$${salt.toString("hex")}$${derived.toString("hex")}`;
}

export function verifyPin(pin, encodedHash) {
  if (!pin || !encodedHash) return false;
  const parts = encodedHash.split("$");
  if (parts.length !== 4 || parts[0] !== PIN_PREFIX) return false;
  const iterations = Number(parts[1]);
  if (!Number.isInteger(iterations) || iterations < 10_000) return false;

  const salt = Buffer.from(parts[2], "hex");
  const expected = Buffer.from(parts[3], "hex");
  if (salt.length === 0 || expected.length === 0) return false;

  const actual = crypto.pbkdf2Sync(Buffer.from(pin, "utf8"), salt, iterations, expected.length, "sha256");
  if (actual.length !== expected.length) return false;
  return crypto.timingSafeEqual(actual, expected);
}

export function isValidPin(pin) {
  return typeof pin === "string" && /^\d{4,12}$/.test(pin.trim());
}

export function isValidHttpUrl(rawUrl) {
  if (typeof rawUrl !== "string") return false;
  try {
    const parsed = new URL(rawUrl.trim());
    return (parsed.protocol === "https:" || parsed.protocol === "http:") && Boolean(parsed.hostname);
  } catch {
    return false;
  }
}

export function generateDeviceToken() {
  return crypto.randomBytes(32).toString("hex");
}

export function sha256Hex(value) {
  return crypto.createHash("sha256").update(String(value), "utf8").digest("hex");
}

export function generateRecoveryCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.randomBytes(8);
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += alphabet[bytes[i] % alphabet.length];
  }
  return code;
}

export function timingSafeEqualStr(a, b) {
  const bufA = Buffer.from(String(a ?? ""), "utf8");
  const bufB = Buffer.from(String(b ?? ""), "utf8");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}
