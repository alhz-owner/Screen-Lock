import dotenv from "dotenv";

dotenv.config();

export function loadConfig(overrides = {}) {
  const adminRaw = overrides.ADMIN_TELEGRAM_ID ?? process.env.ADMIN_TELEGRAM_ID ?? "";
  const adminIds = adminRaw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  return {
    port: Number(overrides.PORT ?? process.env.PORT ?? 3000),
    nodeEnv: overrides.NODE_ENV ?? process.env.NODE_ENV ?? "development",
    backendApiUrl: (overrides.BACKEND_API_URL ?? process.env.BACKEND_API_URL ?? "").replace(/\/+$/, ""),
    telegramBotToken: overrides.TELEGRAM_BOT_TOKEN ?? process.env.TELEGRAM_BOT_TOKEN ?? "",
    adminIds,
    telegramMode: (overrides.TELEGRAM_MODE ?? process.env.TELEGRAM_MODE ?? "polling").toLowerCase(),
    telegramWebhookSecret: overrides.TELEGRAM_WEBHOOK_SECRET ?? process.env.TELEGRAM_WEBHOOK_SECRET ?? "",
    databaseUrl: overrides.DATABASE_URL ?? process.env.DATABASE_URL ?? "",
    sqlitePath: overrides.SQLITE_PATH ?? process.env.SQLITE_PATH ?? "./data/screenlock.db",
    deviceEnrollmentKey: overrides.DEVICE_ENROLLMENT_KEY ?? process.env.DEVICE_ENROLLMENT_KEY ?? "",
    defaultWebsiteUrl: overrides.DEFAULT_WEBSITE_URL ?? process.env.DEFAULT_WEBSITE_URL ?? "https://example.com",
    defaultLockPin: overrides.DEFAULT_LOCK_PIN ?? process.env.DEFAULT_LOCK_PIN ?? "1234",
    defaultUnlockInstructions:
      overrides.DEFAULT_UNLOCK_INSTRUCTIONS ??
      process.env.DEFAULT_UNLOCK_INSTRUCTIONS ??
      "Tap the keyboard icon and enter your administrator-configured PIN. Contact your administrator for an emergency recovery code if needed."
  };
}
