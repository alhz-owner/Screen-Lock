import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {
  generateRecoveryCode,
  hashPin,
  isValidHttpUrl,
  isValidPin,
  sha256Hex
} from "./security.js";

const MAIN_KEYBOARD = {
  inline_keyboard: [
    [
      { text: "🖼 Update Lock Image", callback_data: "menu:update_image" },
      { text: "🔢 Change PIN", callback_data: "menu:change_pin" }
    ],
    [
      { text: "🌐 Update Website URL", callback_data: "menu:update_url" },
      { text: "📝 Update Unlock Instructions", callback_data: "menu:update_instructions" }
    ],
    [
      { text: "📱 Device Management", callback_data: "menu:devices" },
      { text: "📜 Lock History", callback_data: "menu:history" }
    ],
    [
      { text: "🛡 Permission Status", callback_data: "menu:permissions" },
      { text: "🆘 Emergency Recovery", callback_data: "menu:recovery" }
    ]
  ]
};

export function createTelegramAdminController({ config, db, uploadsDir, fetchImpl = fetch }) {
  // Tracks active multi-step prompts per authenticated admin Telegram ID
  const adminStates = new Map();
  let pollingActive = false;
  let lastUpdateId = 0;

  function isAuthorizedAdmin(telegramUserId) {
    const idStr = String(telegramUserId ?? "").trim();
    return Boolean(idStr && config.adminIds.includes(idStr));
  }

  async function callTelegramApi(method, payload) {
    if (!config.telegramBotToken || config.telegramBotToken.startsWith("replace_with")) {
      return { ok: false, skipped: true };
    }
    const url = `https://api.telegram.org/bot${config.telegramBotToken}/${method}`;
    const res = await fetchImpl(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return res.json();
  }

  async function sendMessage(chatId, text, extra = {}) {
    return callTelegramApi("sendMessage", {
      chat_id: chatId,
      text,
      ...extra
    });
  }

  async function sendMenu(chatId, prefix = "") {
    const cfg = await db.getGlobalConfig();
    const devices = await db.listDevices();
    const onlineCount = devices.filter((d) => d.effective_connection_status === "ONLINE").length;
    const text = [
      prefix ? `${prefix}\n\n` : "",
      "🔐 OmayRaa-Akhi — Screen Lock Admin Panel",
      `• Website URL: ${cfg.website_url}`,
      `• Config Version: v${cfg.configuration_version}`,
      `• Enrolled Devices: ${devices.length} (${onlineCount} online)`
    ].join("\n");

    return sendMessage(chatId, text, { reply_markup: MAIN_KEYBOARD });
  }

  async function downloadTelegramFile(fileId) {
    const fileMeta = await callTelegramApi("getFile", { file_id: fileId });
    if (!fileMeta?.ok || !fileMeta.result?.file_path) {
      throw new Error("Could not retrieve uploaded image metadata from Telegram.");
    }
    const filePath = fileMeta.result.file_path;
    const ext = path.extname(filePath).toLowerCase() || ".jpg";
    if (![".jpg", ".jpeg", ".png", ".webp"].includes(ext)) {
      throw new Error("Unsupported image format. Please send a JPG, PNG, or WEBP image.");
    }
    const downloadUrl = `https://api.telegram.org/file/bot${config.telegramBotToken}/${filePath}`;
    const response = await fetchImpl(downloadUrl);
    if (!response.ok) {
      throw new Error(`Telegram file download failed (${response.status}).`);
    }
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    if (buffer.length > 8 * 1024 * 1024) {
      throw new Error("Image exceeds maximum allowed size of 8 MB.");
    }
    fs.mkdirSync(uploadsDir, { recursive: true });
    const filename = `lock_${Date.now()}_${crypto.randomBytes(4).toString("hex")}${ext}`;
    fs.writeFileSync(path.join(uploadsDir, filename), buffer);
    return filename;
  }

  async function handleCallbackQuery(query) {
    const adminId = String(query.from?.id ?? "");
    const chatId = query.message?.chat?.id ?? query.from?.id;

    if (!isAuthorizedAdmin(adminId)) {
      await db.logEvent("TELEGRAM_BOT", "UNAUTHORIZED_TELEGRAM_ACCESS", adminId, "Rejected callback query");
      await callTelegramApi("answerCallbackQuery", {
        callback_query_id: query.id,
        text: "Access denied.",
        show_alert: true
      });
      if (chatId) {
        await sendMessage(chatId, "⛔ Access denied. You are not authorized to administer this bot.");
      }
      return { authorized: false };
    }

    await callTelegramApi("answerCallbackQuery", { callback_query_id: query.id });
    const data = query.data || "";

    if (data === "menu:main") {
      adminStates.delete(adminId);
      await sendMenu(chatId);
      return { authorized: true, action: "menu:main" };
    }

    if (data === "menu:update_image") {
      adminStates.set(adminId, { step: "AWAITING_IMAGE" });
      await sendMessage(chatId, "🖼 Send the new Lock Screen image as a photo or image file (JPG/PNG/WEBP, max 8 MB). Send /cancel to abort.");
      return { authorized: true, action: data };
    }

    if (data === "menu:change_pin") {
      adminStates.set(adminId, { step: "AWAITING_PIN" });
      await sendMessage(chatId, "🔢 Enter the new numeric unlock PIN (4 to 12 digits). For security, it will be hashed immediately and never echoed back. Send /cancel to abort.");
      return { authorized: true, action: data };
    }

    if (data === "menu:update_url") {
      adminStates.set(adminId, { step: "AWAITING_URL" });
      await sendMessage(chatId, "🌐 Send the full website URL (must begin with https:// or http://). Send /cancel to abort.");
      return { authorized: true, action: data };
    }

    if (data === "menu:update_instructions") {
      adminStates.set(adminId, { step: "AWAITING_INSTRUCTIONS" });
      await sendMessage(chatId, "📝 Send the updated 'How to Unlock' instructions for device users. Send /cancel to abort.");
      return { authorized: true, action: data };
    }

    if (data === "menu:devices") {
      const devices = await db.listDevices();
      if (devices.length === 0) {
        await sendMessage(chatId, "📱 No devices have registered yet.", {
          reply_markup: { inline_keyboard: [[{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]] }
        });
        return { authorized: true, action: data };
      }

      const lines = ["📱 Registered Devices:"];
      const buttons = [];
      for (const dev of devices.slice(0, 10)) {
        lines.push(
          `\n• ${dev.device_name} (${dev.device_id})\n  Status: ${dev.effective_connection_status} | Lock: ${dev.lock_status} | Enrollment: ${dev.enrollment_status}\n  Registered: ${dev.registered_at}`
        );
        buttons.push([
          {
            text: dev.lock_status === "LOCKED" ? `🔓 Unlock ${dev.device_name.slice(0, 12)}` : `🔒 Lock ${dev.device_name.slice(0, 12)}`,
            callback_data: dev.lock_status === "LOCKED" ? `dev:unlock:${dev.device_id}` : `dev:lock:${dev.device_id}`
          },
          {
            text: dev.enrollment_status === "ENROLLED" ? "🚫 Suspend" : "✅ Approve",
            callback_data: dev.enrollment_status === "ENROLLED" ? `dev:suspend:${dev.device_id}` : `dev:approve:${dev.device_id}`
          },
          {
            text: "🗑 Remove",
            callback_data: `dev:remove:${dev.device_id}`
          }
        ]);
      }
      buttons.push([{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]);
      await sendMessage(chatId, lines.join("\n"), { reply_markup: { inline_keyboard: buttons } });
      return { authorized: true, action: data };
    }

    if (data.startsWith("dev:")) {
      const [, action, deviceId] = data.split(":");
      if (action === "lock") {
        await db.setDeviceLockStatus(deviceId, "LOCKED", adminId);
        await sendMenu(chatId, `🔒 Remote lock queued for device ${deviceId}.`);
      } else if (action === "unlock") {
        await db.setDeviceLockStatus(deviceId, "UNLOCKED", adminId);
        await sendMenu(chatId, `🔓 Remote unlock queued for device ${deviceId}.`);
      } else if (action === "suspend") {
        await db.setDeviceEnrollmentStatus(deviceId, "SUSPENDED", adminId);
        await sendMenu(chatId, `🚫 Device ${deviceId} suspended.`);
      } else if (action === "approve") {
        await db.setDeviceEnrollmentStatus(deviceId, "ENROLLED", adminId);
        await sendMenu(chatId, `✅ Device ${deviceId} enrolled.`);
      } else if (action === "remove") {
        await db.removeDevice(deviceId, adminId);
        await sendMenu(chatId, `🗑 Device ${deviceId} removed.`);
      }
      return { authorized: true, action: data };
    }

    if (data === "menu:history") {
      const logs = await db.listActivityLogs(15);
      const body =
        logs.length === 0
          ? "📜 No activity events recorded yet."
          : "📜 Recent Lock & Admin History:\n" +
            logs
              .map(
                (l) =>
                  `\n• [${l.event_timestamp}] ${l.event_type} (${l.device_id})${
                    l.administrator_id ? ` by admin ${l.administrator_id}` : ""
                  }${l.details ? ` — ${l.details}` : ""}`
              )
              .join("");
      await sendMessage(chatId, body, {
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]] }
      });
      return { authorized: true, action: data };
    }

    if (data === "menu:permissions") {
      const devices = await db.listDevices();
      if (devices.length === 0) {
        await sendMessage(chatId, "🛡 No enrolled devices reporting permissions yet.", {
          reply_markup: { inline_keyboard: [[{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]] }
        });
        return { authorized: true, action: data };
      }

      const lines = [
        "🛡 Device Permission Status (least-privilege audit):",
        "Users can revoke optional permissions anytime in Android Settings."
      ];
      for (const dev of devices.slice(0, 10)) {
        lines.push(`\n📱 ${dev.device_name} (${dev.device_id})`);
        const entries = Object.entries(dev.permissions || {});
        if (entries.length === 0) {
          lines.push("  • Awaiting first heartbeat");
        } else {
          for (const [permKey, granted] of entries) {
            lines.push(`  • ${permKey}: ${granted ? "✅ GRANTED" : "❌ DENIED"}`);
          }
        }
      }
      await sendMessage(chatId, lines.join("\n"), {
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]] }
      });
      return { authorized: true, action: data };
    }

    if (data === "menu:recovery") {
      const devices = await db.listDevices();
      if (devices.length === 0) {
        await sendMessage(
          chatId,
          "🆘 Owner Emergency Recovery:\nNo devices registered yet. On the device, owners can always tap 'How to Unlock' -> 'Owner Emergency Exit'.",
          { reply_markup: { inline_keyboard: [[{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]] } }
        );
        return { authorized: true, action: data };
      }
      const buttons = devices.slice(0, 8).map((d) => [
        { text: `🔑 Issue Recovery Code: ${d.device_name}`, callback_data: `rec:issue:${d.device_id}` }
      ]);
      buttons.push([{ text: "⬅️ Back to Menu", callback_data: "menu:main" }]);
      await sendMessage(
        chatId,
        "🆘 Select a device to issue a single-use 15-minute Emergency Recovery Code (or advise the owner to use 'How to Unlock' -> 'Owner Emergency Exit' on the device):",
        { reply_markup: { inline_keyboard: buttons } }
      );
      return { authorized: true, action: data };
    }

    if (data.startsWith("rec:issue:")) {
      const deviceId = data.slice("rec:issue:".length);
      const code = generateRecoveryCode();
      const expiresAt = new Date(Date.now() + 15 * 60_000).toISOString();
      await db.setRecoveryCode(deviceId, sha256Hex(code), expiresAt, adminId);
      await sendMenu(
        chatId,
        `🆘 Emergency Recovery Code for ${deviceId}:\n\nCode: ${code}\nExpires: ${expiresAt}\n\nShare this one-time code directly with the device owner. On the lock screen, tap 'How to Unlock' and enter this code.`
      );
      return { authorized: true, action: data };
    }

    return { authorized: true, action: "unknown" };
  }

  async function handleMessage(msg) {
    const adminId = String(msg.from?.id ?? "");
    const chatId = msg.chat?.id;
    const text = (msg.text || "").trim();

    if (!isAuthorizedAdmin(adminId)) {
      await db.logEvent("TELEGRAM_BOT", "UNAUTHORIZED_TELEGRAM_ACCESS", adminId, "Rejected message command");
      if (chatId) {
        await sendMessage(chatId, "⛔ Access denied. You are not authorized to administer this bot.");
      }
      return { authorized: false };
    }

    if (text === "/cancel") {
      adminStates.delete(adminId);
      await sendMenu(chatId, "Cancelled current action.");
      return { authorized: true, action: "cancel" };
    }

    if (text === "/start" || text === "/menu") {
      adminStates.delete(adminId);
      await sendMenu(chatId);
      return { authorized: true, action: "start" };
    }

    const currentState = adminStates.get(adminId);
    if (!currentState) {
      await sendMenu(chatId);
      return { authorized: true, action: "menu_fallback" };
    }

    if (currentState.step === "AWAITING_URL") {
      if (!isValidHttpUrl(text)) {
        await sendMessage(chatId, "❌ Invalid URL. Please enter a valid https:// or http:// URL, or /cancel.");
        return { authorized: true, action: "invalid_url" };
      }
      await db.updateWebsiteUrl(text, adminId);
      adminStates.delete(adminId);
      await sendMenu(chatId, `✅ Website URL updated to ${text}. Enrolled devices will sync automatically.`);
      return { authorized: true, action: "url_updated" };
    }

    if (currentState.step === "AWAITING_PIN") {
      if (!isValidPin(text)) {
        await sendMessage(chatId, "❌ Invalid PIN. Enter 4 to 12 numeric digits only, or /cancel.");
        return { authorized: true, action: "invalid_pin" };
      }
      const hashed = hashPin(text);
      await db.updatePinHash(hashed, adminId);
      adminStates.delete(adminId);
      // Best-effort deletion of admin's plaintext PIN message from chat history
      if (msg.message_id) {
        await callTelegramApi("deleteMessage", { chat_id: chatId, message_id: msg.message_id }).catch(() => {});
      }
      await sendMenu(chatId, "✅ Unlock PIN updated and hashed (PBKDF2-HMAC-SHA256). Plaintext PIN was never stored.");
      return { authorized: true, action: "pin_updated" };
    }

    if (currentState.step === "AWAITING_INSTRUCTIONS") {
      if (text.length < 3 || text.length > 1000) {
        await sendMessage(chatId, "❌ Instructions must be between 3 and 1000 characters.");
        return { authorized: true, action: "invalid_instructions" };
      }
      await db.updateUnlockInstructions(text, adminId);
      adminStates.delete(adminId);
      await sendMenu(chatId, "✅ Unlock instructions updated and synced.");
      return { authorized: true, action: "instructions_updated" };
    }

    if (currentState.step === "AWAITING_IMAGE") {
      const photos = msg.photo || [];
      const doc = msg.document;
      const fileId = photos.length > 0 ? photos[photos.length - 1].file_id : doc?.file_id;
      if (!fileId) {
        await sendMessage(chatId, "❌ Please upload an image photo or file, or send /cancel.");
        return { authorized: true, action: "awaiting_image" };
      }
      try {
        const filename = await downloadTelegramFile(fileId);
        const relativeUrl = `/api/media/${filename}`;
        await db.updateLockImageUrl(relativeUrl, adminId);
        adminStates.delete(adminId);
        await callTelegramApi("sendPhoto", {
          chat_id: chatId,
          photo: fileId,
          caption: "✅ Lock screen image updated! Preview above. Enrolled devices will download it on next sync."
        });
        await sendMenu(chatId);
        return { authorized: true, action: "image_updated" };
      } catch (err) {
        await sendMessage(chatId, `❌ Upload error: ${err.message}`);
        return { authorized: true, action: "image_error" };
      }
    }

    return { authorized: true, action: "noop" };
  }

  async function processUpdate(update) {
    if (!update || typeof update !== "object") return { ignored: true };
    if (update.callback_query) {
      return handleCallbackQuery(update.callback_query);
    }
    if (update.message) {
      return handleMessage(update.message);
    }
    return { ignored: true };
  }

  async function startPolling() {
    if (!config.telegramBotToken || config.telegramBotToken.startsWith("replace_with")) {
      return;
    }
    pollingActive = true;
    while (pollingActive) {
      try {
        const res = await callTelegramApi("getUpdates", {
          offset: lastUpdateId + 1,
          timeout: 25,
          allowed_updates: ["message", "callback_query"]
        });
        if (res?.ok && Array.isArray(res.result)) {
          for (const upd of res.result) {
            lastUpdateId = Math.max(lastUpdateId, upd.update_id);
            await processUpdate(upd);
          }
        }
      } catch {
        await new Promise((r) => setTimeout(r, 3000));
      }
    }
  }

  function stopPolling() {
    pollingActive = false;
  }

  return {
    processUpdate,
    startPolling,
    stopPolling,
    isAuthorizedAdmin
  };
}
