import fs from "node:fs";
import path from "node:path";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { loadConfig } from "./config.js";
import { createDatabase } from "./db.js";
import { createTelegramAdminController } from "./telegramBot.js";
import {
  generateDeviceToken,
  sha256Hex,
  timingSafeEqualStr
} from "./security.js";

export async function createApp(configOverrides = {}, { fetchImpl } = {}) {
  const config = loadConfig(configOverrides);
  const db = await createDatabase(config);
  const uploadsDir = path.resolve(configOverrides.UPLOADS_DIR || "./uploads");
  fs.mkdirSync(uploadsDir, { recursive: true });

  const bot = createTelegramAdminController({
    config,
    db,
    uploadsDir,
    fetchImpl
  });

  const app = express();
  app.set("trust proxy", 1);
  app.use(helmet());
  app.use(express.json({ limit: "1mb" }));

  const registerLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 60,
    standardHeaders: true,
    legacyHeaders: false
  });

  const recoveryLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 30,
    standardHeaders: true,
    legacyHeaders: false
  });

  const webhookLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false
  });

  async function requireDeviceAuth(req, res, next) {
    const deviceId = req.params.deviceId;
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
    if (!deviceId || !token) {
      return res.status(401).json({ error: "Missing device authorization token." });
    }
    const device = await db.getDevice(deviceId);
    if (!device) {
      return res.status(404).json({ error: "Device not registered." });
    }
    if (!timingSafeEqualStr(device.token_hash, sha256Hex(token))) {
      return res.status(401).json({ error: "Invalid device token." });
    }
    if (device.enrollment_status === "SUSPENDED") {
      return res.status(403).json({ error: "Device enrollment is suspended by administrator." });
    }
    req.device = device;
    return next();
  }

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", service: "omayraa-akhi-backend", timestamp: new Date().toISOString() });
  });

  app.post("/api/devices/register", registerLimiter, async (req, res) => {
    const { device_id: deviceId, device_name: deviceName, enrollment_key: enrollmentKey, permissions } = req.body || {};
    if (!deviceId || typeof deviceId !== "string" || deviceId.length > 100) {
      return res.status(400).json({ error: "Valid device_id is required." });
    }
    if (config.deviceEnrollmentKey && !timingSafeEqualStr(enrollmentKey || "", config.deviceEnrollmentKey)) {
      return res.status(403).json({ error: "Invalid device enrollment key." });
    }

    const rawToken = generateDeviceToken();
    const tokenHash = sha256Hex(rawToken);
    const device = await db.registerOrRefreshDevice({
      deviceId: deviceId.trim(),
      deviceName: String(deviceName || "Android Device").slice(0, 120),
      tokenHash,
      permissions: permissions && typeof permissions === "object" ? permissions : {}
    });

    const data = await db.getDeviceWithPin(device.device_id);
    return res.status(200).json({
      device_id: device.device_id,
      device_token: rawToken,
      enrollment_status: device.enrollment_status,
      lock_status: device.lock_status,
      config: data.config
    });
  });

  app.get("/api/devices/:deviceId/sync", requireDeviceAuth, async (req, res) => {
    await db.touchDeviceLastSeen(req.device.device_id);
    const data = await db.getDeviceWithPin(req.device.device_id);
    return res.json({
      device_id: data.device.device_id,
      enrollment_status: data.device.enrollment_status,
      lock_status: data.device.lock_status,
      config: data.config
    });
  });

  app.post("/api/devices/:deviceId/heartbeat", requireDeviceAuth, async (req, res) => {
    const { connection_status: connectionStatus, lock_status: lockStatus, permissions } = req.body || {};
    await db.updateDeviceHeartbeat(req.device.device_id, {
      connectionStatus: connectionStatus === "OFFLINE" ? "OFFLINE" : "ONLINE",
      lockStatus: lockStatus === "LOCKED" ? "LOCKED" : "UNLOCKED",
      permissions: permissions && typeof permissions === "object" ? permissions : {}
    });
    return res.json({ ok: true, message: "Heartbeat recorded" });
  });

  app.post("/api/devices/:deviceId/events", requireDeviceAuth, async (req, res) => {
    const { event_type: eventType, details } = req.body || {};
    if (!eventType || typeof eventType !== "string") {
      return res.status(400).json({ error: "event_type is required." });
    }
    await db.logEvent(
      req.device.device_id,
      eventType.slice(0, 64),
      null,
      details ? String(details).slice(0, 500) : null
    );
    return res.json({ ok: true, message: "Event logged" });
  });

  app.post("/api/devices/:deviceId/recovery/verify", recoveryLimiter, requireDeviceAuth, async (req, res) => {
    const { recovery_code: recoveryCode } = req.body || {};
    if (!recoveryCode || typeof recoveryCode !== "string") {
      return res.status(400).json({ valid: false, message: "recovery_code is required." });
    }
    const valid = await db.consumeRecoveryCode(req.device.device_id, sha256Hex(recoveryCode.trim().toUpperCase()));
    return res.json({
      valid,
      message: valid ? "Recovery code verified." : "Invalid or expired recovery code."
    });
  });

  app.get("/api/media/:filename", (req, res) => {
    const safeName = path.basename(req.params.filename || "");
    if (!safeName || !/^[a-zA-Z0-9._-]+$/.test(safeName)) {
      return res.status(400).json({ error: "Invalid filename." });
    }
    const fullPath = path.join(uploadsDir, safeName);
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: "Media file not found." });
    }
    return res.sendFile(fullPath);
  });

  app.post("/api/telegram/webhook", webhookLimiter, async (req, res) => {
    if (config.telegramWebhookSecret) {
      const provided = req.headers["x-telegram-bot-api-secret-token"] || "";
      if (!timingSafeEqualStr(provided, config.telegramWebhookSecret)) {
        return res.status(403).json({ error: "Invalid webhook secret token." });
      }
    }
    await bot.processUpdate(req.body);
    return res.json({ ok: true });
  });

  return { app, db, bot, config };
}

const isEntrypoint = import.meta.url === `file://${process.argv[1]}`;
if (isEntrypoint) {
  const { app, bot, config } = await createApp();
  app.listen(config.port, () => {
    console.log(`OmayRaa-Akhi backend listening on port ${config.port}`);
    if (config.telegramMode === "polling") {
      bot.startPolling();
    }
  });
}
