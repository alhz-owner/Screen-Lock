import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import pg from "pg";
import { hashPin } from "./security.js";

const { Pool } = pg;

export async function createDatabase(config) {
  const isPostgres = Boolean(config.databaseUrl && config.databaseUrl.trim());
  let sqlite = null;
  let pool = null;

  if (isPostgres) {
    pool = new Pool({
      connectionString: config.databaseUrl,
      ssl: config.nodeEnv === "production" ? { rejectUnauthorized: false } : false
    });
  } else {
    if (config.sqlitePath !== ":memory:") {
      fs.mkdirSync(path.dirname(path.resolve(config.sqlitePath)), { recursive: true });
    }
    sqlite = new DatabaseSync(config.sqlitePath);
  }

  async function run(sql, params = []) {
    if (isPostgres) {
      let idx = 0;
      const pgSql = sql.replace(/\?/g, () => `$${++idx}`);
      const res = await pool.query(pgSql, params);
      return res;
    }
    const stmt = sqlite.prepare(sql);
    const trimmed = sql.trim().toUpperCase();
    if (trimmed.startsWith("SELECT")) {
      return { rows: stmt.all(...params) };
    }
    const info = stmt.run(...params);
    return { rows: [], lastInsertRowid: info.lastInsertRowid, changes: info.changes };
  }

  async function initSchema() {
    const autoIdType = isPostgres ? "SERIAL PRIMARY KEY" : "INTEGER PRIMARY KEY AUTOINCREMENT";
    const statements = [
      `CREATE TABLE IF NOT EXISTS Admins (
        admin_id TEXT PRIMARY KEY,
        role TEXT NOT NULL DEFAULT 'SUPER_ADMIN',
        created_at TEXT NOT NULL
      )`,
      `CREATE TABLE IF NOT EXISTS Devices (
        device_id TEXT PRIMARY KEY,
        device_name TEXT NOT NULL,
        enrollment_status TEXT NOT NULL DEFAULT 'ENROLLED',
        connection_status TEXT NOT NULL DEFAULT 'OFFLINE',
        lock_status TEXT NOT NULL DEFAULT 'UNLOCKED',
        registered_at TEXT NOT NULL,
        last_seen TEXT NOT NULL,
        token_hash TEXT NOT NULL,
        permissions_json TEXT NOT NULL DEFAULT '{}'
      )`,
      `CREATE TABLE IF NOT EXISTS AppConfiguration (
        id INTEGER PRIMARY KEY,
        website_url TEXT NOT NULL,
        lock_image_url TEXT NOT NULL DEFAULT '',
        unlock_instructions TEXT NOT NULL,
        configuration_version INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL
      )`,
      `CREATE TABLE IF NOT EXISTS Security (
        device_id TEXT PRIMARY KEY,
        pin_hash TEXT NOT NULL,
        pin_updated_at TEXT NOT NULL,
        recovery_configuration TEXT NOT NULL DEFAULT '{}'
      )`,
      `CREATE TABLE IF NOT EXISTS ActivityLogs (
        id ${autoIdType},
        device_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        event_timestamp TEXT NOT NULL,
        administrator_id TEXT,
        details TEXT
      )`
    ];

    for (const stmt of statements) {
      await run(stmt);
    }

    const now = new Date().toISOString();
    for (const adminId of config.adminIds) {
      await run(
        `INSERT INTO Admins (admin_id, role, created_at)
         VALUES (?, 'SUPER_ADMIN', ?)
         ON CONFLICT (admin_id) DO NOTHING`,
        [adminId, now]
      );
    }

    const existingConfig = await run(`SELECT id FROM AppConfiguration WHERE id = 1`);
    if (existingConfig.rows.length === 0) {
      await run(
        `INSERT INTO AppConfiguration (id, website_url, lock_image_url, unlock_instructions, configuration_version, updated_at)
         VALUES (1, ?, '', ?, 1, ?)`,
        [config.defaultWebsiteUrl, config.defaultUnlockInstructions, now]
      );
    }

    const existingGlobalPin = await run(`SELECT device_id FROM Security WHERE device_id = '__GLOBAL__'`);
    if (existingGlobalPin.rows.length === 0) {
      const initialPinHash = hashPin(config.defaultLockPin || "1234");
      await run(
        `INSERT INTO Security (device_id, pin_hash, pin_updated_at, recovery_configuration)
         VALUES ('__GLOBAL__', ?, ?, '{}')`,
        [initialPinHash, now]
      );
    }
  }

  await initSchema();

  return {
    async close() {
      if (pool) await pool.end();
      if (sqlite) sqlite.close();
    },

    async getGlobalConfig() {
      const cfgRes = await run(`SELECT * FROM AppConfiguration WHERE id = 1`);
      const secRes = await run(`SELECT pin_hash, pin_updated_at FROM Security WHERE device_id = '__GLOBAL__'`);
      const cfg = cfgRes.rows[0];
      const sec = secRes.rows[0];
      return {
        website_url: cfg.website_url,
        lock_image_url: cfg.lock_image_url || "",
        unlock_instructions: cfg.unlock_instructions,
        configuration_version: Number(cfg.configuration_version),
        pin_hash: sec?.pin_hash || "",
        updated_at: cfg.updated_at
      };
    },

    async updateWebsiteUrl(websiteUrl, adminId) {
      const now = new Date().toISOString();
      await run(
        `UPDATE AppConfiguration
         SET website_url = ?, configuration_version = configuration_version + 1, updated_at = ?
         WHERE id = 1`,
        [websiteUrl, now]
      );
      await this.logEvent("ALL_DEVICES", "ADMIN_UPDATE_URL", adminId, `Updated website URL to ${websiteUrl}`);
      return this.getGlobalConfig();
    },

    async updateLockImageUrl(lockImageUrl, adminId) {
      const now = new Date().toISOString();
      await run(
        `UPDATE AppConfiguration
         SET lock_image_url = ?, configuration_version = configuration_version + 1, updated_at = ?
         WHERE id = 1`,
        [lockImageUrl, now]
      );
      await this.logEvent("ALL_DEVICES", "ADMIN_UPDATE_IMAGE", adminId, "Updated lock screen background image");
      return this.getGlobalConfig();
    },

    async updateUnlockInstructions(instructions, adminId) {
      const now = new Date().toISOString();
      await run(
        `UPDATE AppConfiguration
         SET unlock_instructions = ?, configuration_version = configuration_version + 1, updated_at = ?
         WHERE id = 1`,
        [instructions, now]
      );
      await this.logEvent("ALL_DEVICES", "ADMIN_UPDATE_INSTRUCTIONS", adminId, "Updated unlock instructions");
      return this.getGlobalConfig();
    },

    async updatePinHash(pinHash, adminId) {
      const now = new Date().toISOString();
      await run(
        `INSERT INTO Security (device_id, pin_hash, pin_updated_at, recovery_configuration)
         VALUES ('__GLOBAL__', ?, ?, '{}')
         ON CONFLICT (device_id) DO UPDATE SET pin_hash = excluded.pin_hash, pin_updated_at = excluded.pin_updated_at`,
        [pinHash, now]
      );
      await run(
        `UPDATE Security SET pin_hash = ?, pin_updated_at = ? WHERE device_id != '__GLOBAL__'`,
        [pinHash, now]
      );
      await run(
        `UPDATE AppConfiguration SET configuration_version = configuration_version + 1, updated_at = ? WHERE id = 1`,
        [now]
      );
      await this.logEvent("ALL_DEVICES", "ADMIN_CHANGE_PIN", adminId, "Administrator updated device unlock PIN hash");
    },

    async registerOrRefreshDevice({ deviceId, deviceName, tokenHash, permissions }) {
      const now = new Date().toISOString();
      const permissionsJson = JSON.stringify(permissions || {});
      const existing = await run(`SELECT * FROM Devices WHERE device_id = ?`, [deviceId]);

      if (existing.rows.length === 0) {
        await run(
          `INSERT INTO Devices (device_id, device_name, enrollment_status, connection_status, lock_status, registered_at, last_seen, token_hash, permissions_json)
           VALUES (?, ?, 'ENROLLED', 'ONLINE', 'UNLOCKED', ?, ?, ?, ?)`,
          [deviceId, deviceName, now, now, tokenHash, permissionsJson]
        );
        const globalCfg = await this.getGlobalConfig();
        await run(
          `INSERT INTO Security (device_id, pin_hash, pin_updated_at, recovery_configuration)
           VALUES (?, ?, ?, '{}')
           ON CONFLICT (device_id) DO NOTHING`,
          [deviceId, globalCfg.pin_hash, now]
        );
        await this.logEvent(deviceId, "DEVICE_REGISTERED", null, `Enrolled ${deviceName}`);
      } else {
        await run(
          `UPDATE Devices
           SET device_name = ?, connection_status = 'ONLINE', last_seen = ?, token_hash = ?, permissions_json = ?
           WHERE device_id = ?`,
          [deviceName, now, tokenHash, permissionsJson, deviceId]
        );
        await this.logEvent(deviceId, "DEVICE_REAUTHENTICATED", null, `Refreshed token for ${deviceName}`);
      }
      return this.getDevice(deviceId);
    },

    async getDevice(deviceId) {
      const res = await run(`SELECT * FROM Devices WHERE device_id = ?`, [deviceId]);
      return res.rows[0] || null;
    },

    async getDeviceWithPin(deviceId) {
      const dev = await this.getDevice(deviceId);
      if (!dev) return null;
      const secRes = await run(`SELECT * FROM Security WHERE device_id = ?`, [deviceId]);
      const globalCfg = await this.getGlobalConfig();
      const sec = secRes.rows[0];
      return {
        device: dev,
        config: {
          ...globalCfg,
          pin_hash: sec?.pin_hash || globalCfg.pin_hash
        },
        recovery_configuration: sec?.recovery_configuration || "{}"
      };
    },

    async listDevices() {
      const res = await run(`SELECT * FROM Devices ORDER BY registered_at DESC`);
      const nowMs = Date.now();
      return res.rows.map((row) => {
        const lastSeenMs = Date.parse(row.last_seen || "");
        const online = Number.isFinite(lastSeenMs) && nowMs - lastSeenMs < 120_000;
        return {
          ...row,
          effective_connection_status: online ? "ONLINE" : "OFFLINE",
          permissions: safeParseJson(row.permissions_json, {})
        };
      });
    },

    async updateDeviceHeartbeat(deviceId, { connectionStatus, lockStatus, permissions }) {
      const now = new Date().toISOString();
      await run(
        `UPDATE Devices
         SET connection_status = ?, lock_status = ?, last_seen = ?, permissions_json = ?
         WHERE device_id = ?`,
        [connectionStatus || "ONLINE", lockStatus || "UNLOCKED", now, JSON.stringify(permissions || {}), deviceId]
      );
    },

    async touchDeviceLastSeen(deviceId) {
      const now = new Date().toISOString();
      await run(
        `UPDATE Devices SET connection_status = 'ONLINE', last_seen = ? WHERE device_id = ?`,
        [now, deviceId]
      );
    },

    async setDeviceLockStatus(deviceId, lockStatus, adminId) {
      await run(`UPDATE Devices SET lock_status = ? WHERE device_id = ?`, [lockStatus, deviceId]);
      await this.logEvent(deviceId, lockStatus === "LOCKED" ? "ADMIN_LOCK_DEVICE" : "ADMIN_UNLOCK_DEVICE", adminId, `Admin set status to ${lockStatus}`);
    },

    async setDeviceEnrollmentStatus(deviceId, enrollmentStatus, adminId) {
      await run(`UPDATE Devices SET enrollment_status = ? WHERE device_id = ?`, [enrollmentStatus, deviceId]);
      await this.logEvent(deviceId, "ADMIN_ENROLLMENT_CHANGE", adminId, `Enrollment set to ${enrollmentStatus}`);
    },

    async removeDevice(deviceId, adminId) {
      await run(`DELETE FROM Security WHERE device_id = ?`, [deviceId]);
      await run(`DELETE FROM Devices WHERE device_id = ?`, [deviceId]);
      await this.logEvent(deviceId, "ADMIN_REMOVE_DEVICE", adminId, "Device removed by administrator");
    },

    async setRecoveryCode(deviceId, codeHash, expiresAt, adminId) {
      const recoveryJson = JSON.stringify({ code_hash: codeHash, expires_at: expiresAt });
      const now = new Date().toISOString();
      const globalCfg = await this.getGlobalConfig();
      await run(
        `INSERT INTO Security (device_id, pin_hash, pin_updated_at, recovery_configuration)
         VALUES (?, ?, ?, ?)
         ON CONFLICT (device_id) DO UPDATE SET recovery_configuration = excluded.recovery_configuration`,
        [deviceId, globalCfg.pin_hash, now, recoveryJson]
      );
      await this.logEvent(deviceId, "ADMIN_ISSUE_RECOVERY", adminId, "Issued one-time emergency recovery code");
    },

    async consumeRecoveryCode(deviceId, candidateHash) {
      const secRes = await run(`SELECT recovery_configuration FROM Security WHERE device_id = ?`, [deviceId]);
      if (secRes.rows.length === 0) return false;
      const cfg = safeParseJson(secRes.rows[0].recovery_configuration, {});
      if (!cfg.code_hash || !cfg.expires_at) return false;
      if (Date.now() > Date.parse(cfg.expires_at)) return false;
      if (cfg.code_hash !== candidateHash) return false;

      await run(`UPDATE Security SET recovery_configuration = '{}' WHERE device_id = ?`, [deviceId]);
      await run(`UPDATE Devices SET lock_status = 'UNLOCKED' WHERE device_id = ?`, [deviceId]);
      await this.logEvent(deviceId, "EMERGENCY_RECOVERY", null, "Device unlocked via one-time recovery code");
      return true;
    },

    async logEvent(deviceId, eventType, administratorId, details) {
      const now = new Date().toISOString();
      await run(
        `INSERT INTO ActivityLogs (device_id, event_type, event_timestamp, administrator_id, details)
         VALUES (?, ?, ?, ?, ?)`,
        [deviceId, eventType, now, administratorId ?? null, details ?? null]
      );
    },

    async listActivityLogs(limit = 15) {
      const res = await run(
        `SELECT * FROM ActivityLogs ORDER BY id DESC LIMIT ?`,
        [limit]
      );
      return res.rows;
    }
  };
}

function safeParseJson(str, fallback) {
  try {
    return JSON.parse(str || "");
  } catch {
    return fallback;
  }
}
