# Android APK & AAB Build Instructions

## 1. Building with Gradle CLI

Bake your production `BACKEND_API_URL` at build time (no Telegram secrets are ever embedded):

```bash
gradle assembleDebug -PBACKEND_API_URL=https://api.your-domain.com
```

For a release App Bundle or APK (configured with your upload keystore environment variables `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`):

```bash
gradle bundleRelease -PBACKEND_API_URL=https://api.your-domain.com
```

Outputs are generated under:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/bundle/release/app-release.aab`

## 2. Building in Android Studio

1. Open the repository root in Android Studio.
2. Sync Gradle (`File > Sync Project with Gradle Files`).
3. Choose `Build > Generate Signed Bundle / APK...` or run directly on a connected physical Android device (`Shift+F10`).

## 3. Optional Managed Kiosk (Device Owner) Enrollment

On dedicated enterprise/kiosk devices freshly factory-reset without user accounts, the device owner may explicitly authorize LockTask pinning:

```bash
adb shell dpm set-device-owner com.aistudio.screenlock.qvxnkp/com.example.device.ScreenLockDeviceAdminReceiver
```

On standard personal devices, LockTask uses standard Android user-confirmed Screen Pinning and never restricts power controls, notifications, or emergency calls.
