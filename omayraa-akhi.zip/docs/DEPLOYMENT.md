# Backend Deployment Instructions

## 1. Production Database Setup (PostgreSQL)

1. Provision a managed PostgreSQL instance (Cloud SQL, RDS, Render, Neon, or Supabase).
2. Set `DATABASE_URL` in your hosting provider's secret environment variables (e.g., `postgresql://user:pass@host:5432/screenlock`).
3. On startup, `backend/src/db.js` automatically ensures the schema (`Admins`, `Devices`, `AppConfiguration`, `Security`, `ActivityLogs`) from `backend/db/schema.sql` exists and seeds the configured `ADMIN_TELEGRAM_ID`.

## 2. HTTPS & Webhook Deployment

1. Deploy `backend/` to a Node.js 22+ host with automatic TLS (Cloud Run, Render, Fly.io, Railway, or Nginx reverse proxy with Let's Encrypt).
2. Configure production environment variables:
   ```env
   NODE_ENV=production
   PORT=3000
   BACKEND_API_URL=https://api.your-domain.com
   TELEGRAM_BOT_TOKEN=<your-bot-token>
   ADMIN_TELEGRAM_ID=<your-telegram-user-id>
   TELEGRAM_MODE=webhook
   TELEGRAM_WEBHOOK_SECRET=<random-64-char-hex-secret>
   DATABASE_URL=postgresql://...
   DEVICE_ENROLLMENT_KEY=<optional-shared-enrollment-key>
   ```
3. Register the Telegram Webhook with secret token verification:
   ```bash
   curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
     -H "Content-Type: application/json" \
     -d '{
       "url": "https://api.your-domain.com/api/telegram/webhook",
       "secret_token": "'"${TELEGRAM_WEBHOOK_SECRET}"'",
       "allowed_updates": ["message", "callback_query"]
     }'
   ```
4. Verify health:
   ```bash
   curl https://api.your-domain.com/health
   ```
