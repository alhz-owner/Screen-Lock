# Installation Guide

## 1. Prerequisites

- **Node.js** >= 22.0.0 and **npm** >= 10
- **PostgreSQL** 15+ (for production) or zero-config SQLite (built into Node 22 for local testing)
- **Android Studio** Ladybug / Meerkat+ (JDK 17, Android SDK 36)
- A **Telegram Bot Token** from `@BotFather` and your numeric **Telegram User ID** (e.g., via `@userinfobot`)

## 2. Backend Configuration

1. Navigate to `backend/` and copy the example environment file:
   ```bash
   cp backend/.env.example backend/.env
   ```
2. Edit `backend/.env`:
   - `TELEGRAM_BOT_TOKEN`: Token issued by `@BotFather` (keep strictly on the backend; never embed in the Android APK).
   - `ADMIN_TELEGRAM_ID`: Your numeric Telegram user ID (or comma-separated IDs).
   - `BACKEND_API_URL`: Public HTTPS URL where the backend will be hosted.
   - `TELEGRAM_MODE`: Use `polling` for local development or `webhook` for production HTTPS.
   - `TELEGRAM_WEBHOOK_SECRET`: Long random string for `X-Telegram-Bot-Api-Secret-Token`.
   - `DATABASE_URL`: PostgreSQL connection URI (leave blank locally to use `./data/screenlock.db`).
   - `DEFAULT_WEBSITE_URL`: Initial website opened in the Android WebView.
   - `DEFAULT_LOCK_PIN`: Initial numeric PIN (4–12 digits, hashed immediately on startup).
3. Install dependencies and start the server:
   ```bash
   cd backend
   npm install
   npm start
   ```
4. Open Telegram, message `/start` to your bot, and use the inline menu to configure the website URL, lock image, unlock instructions, and PIN.

## 3. Android Configuration

- Set `BACKEND_API_URL` in your CI/build environment or Gradle property (`-PBACKEND_API_URL=https://your-backend-domain.com`), or enter it directly on the device's Connection Error setup screen during initial pairing.
- Never place `TELEGRAM_BOT_TOKEN` or `ADMIN_TELEGRAM_ID` inside the Android project.
