# Security & Testing Documentation

## 1. Security Architecture

- **No Client-Side Bot Secrets**: `TELEGRAM_BOT_TOKEN` and `ADMIN_TELEGRAM_ID` exist solely on the backend server.
- **Telegram Admin Whitelist**: Every incoming message and callback query checks `from.id` against `ADMIN_TELEGRAM_ID`. Unauthorized users receive an access-denied message and an `UNAUTHORIZED_TELEGRAM_ACCESS` audit record.
- **Webhook Verification**: Production webhooks verify `X-Telegram-Bot-Api-Secret-Token` using `crypto.timingSafeEqual`.
- **PIN Hashing (PBKDF2-HMAC-SHA256)**: PINs are hashed with 16-byte random salts and 100,000 iterations (`pbkdf2_sha256$100000$<salt>$<hash>`). Plaintext PINs are never stored, never logged, and admin PIN messages are deleted best-effort from Telegram chat.
- **Encrypted Device Storage**: Device bearer tokens and PIN hashes are encrypted on Android via AndroidKeyStore AES-256-GCM inside DataStore Preferences.
- **Least-Privilege Permissions**: Only `INTERNET`, `ACCESS_NETWORK_STATE`, `RECEIVE_BOOT_COMPLETED`, and optional `POST_NOTIFICATIONS` (for visible boot recovery alerts) are declared. Camera, microphone, location, and gallery permissions are excluded.
- **Owner-Controlled Recovery**: Device owners are never permanently locked out—both admin-issued single-use 15-minute recovery codes and a confirmed local Owner Emergency Exit safeguard are always available under "How to Unlock".
- **Rate Limiting & Transport Security**: Express `helmet` headers, `express-rate-limit` on registration/recovery/webhook routes, and Android `network_security_config.xml` enforcing HTTPS outside local loopback development.

## 2. Running Automated Tests

### Backend Tests (`node --test`)
```bash
cd backend
npm install
npm test
```
Tests verify device registration, bearer token auth, PBKDF2 PIN compatibility, webhook secret enforcement, Telegram admin access denial/approval, URL updates, and one-time recovery code consumption.

### Android Unit & Robolectric UI Tests
```bash
gradle :app:testDebugUnitTest
```
Tests verify PBKDF2 PIN hashing/verification, permission least-privilege hygiene, LockScreen controls (`open_pin_button`, `how_to_unlock_button`), and ConnectionErrorScreen retry flow.
