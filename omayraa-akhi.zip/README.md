# OmayRaa-Akhi (Screen Lock / Viral Link)

Consent-based Android kiosk and screen-lock application paired with a Telegram Bot remote administration backend.

## Architecture Overview

- **Android App (`/app`)**: Kotlin + Jetpack Compose + Material 3. Opens the administrator-configured website directly in a minimal WebView with no traditional home screen or dashboard. Supports a user-authorized fullscreen lock screen with PIN entry, admin-configured unlock instructions, owner-controlled emergency recovery, and reboot state recovery.
- **Backend & Telegram Bot (`/backend`)**: Node.js + Express + PostgreSQL (or embedded SQLite for local dev) + Telegram Bot API. Provides all administrative controls exclusively via Telegram inline keyboards (`ADMIN_TELEGRAM_ID` whitelist, PBKDF2-HMAC-SHA256 PIN hashing, device enrollment, lock history, permission audit, and one-time emergency recovery codes).

## Documentation

- [Installation & Environment Setup](docs/INSTALLATION.md)
- [Backend Deployment Guide](docs/DEPLOYMENT.md)
- [Android APK / AAB Build Instructions](docs/ANDROID_BUILD.md)
- [Security & Testing Documentation](docs/SECURITY_AND_TESTING.md)
