package com.example.device

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.MainActivity
import com.example.data.security.SecureStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Visible, compliant boot recovery receiver.
 * Restores previously authorized kiosk/lock state after reboot without hidden persistence.
 * On Device Owner enrolled devices, launches MainActivity directly; on standard devices,
 * posts a visible recovery notification in compliance with Android 10+ background launch rules.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val storage = SecureStorage(appContext)
                val snapshot = storage.getSnapshot()
                if (!snapshot.bootRecoveryEnabled) return@launch

                if (snapshot.isLocked || snapshot.websiteUrl.isNotBlank()) {
                    ScreenLockNotificationManager.showBootRecoveryNotification(
                        context = appContext,
                        isLocked = snapshot.isLocked
                    )
                    if (KioskController.isDeviceOwner(appContext) && snapshot.isLocked) {
                        val launchIntent = Intent(appContext, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra(ScreenLockNotificationManager.EXTRA_BOOT_RECOVERY, true)
                            putExtra(ScreenLockNotificationManager.EXTRA_WAS_LOCKED, true)
                        }
                        runCatching { appContext.startActivity(launchIntent) }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
