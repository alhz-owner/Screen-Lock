package com.example.device

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * Optional DeviceAdminReceiver for organizations or device owners who explicitly enroll
 * their dedicated device via Android Enterprise / ADB device owner provisioning.
 */
class ScreenLockDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }
}
