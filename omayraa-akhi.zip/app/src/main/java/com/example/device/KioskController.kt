package com.example.device

import android.app.Activity
import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

/**
 * Coordinates user-authorized kiosk pinning via Android LockTask APIs.
 * Never blocks emergency calls, incoming notifications/calls, or physical power controls.
 */
object KioskController {

    fun isDeviceOwner(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        return dpm?.isDeviceOwnerApp(context.packageName) == true
    }

    fun isInLockTaskMode(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return false
        return am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    }

    fun enterLockTask(activity: Activity) {
        runCatching {
            val dpm = activity.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            if (dpm != null && dpm.isDeviceOwnerApp(activity.packageName)) {
                val adminComponent = ComponentName(activity, ScreenLockDeviceAdminReceiver::class.java)
                dpm.setLockTaskPackages(adminComponent, arrayOf(activity.packageName))
            }
            if (!isInLockTaskMode(activity)) {
                activity.startLockTask()
            }
        }
    }

    fun exitLockTask(activity: Activity) {
        runCatching {
            if (isInLockTaskMode(activity)) {
                activity.stopLockTask()
            }
        }
    }
}
