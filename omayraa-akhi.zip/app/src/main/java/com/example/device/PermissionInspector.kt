package com.example.device

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

data class AppPermissionStatus(
    val permissionKey: String,
    val label: String,
    val granted: Boolean,
    val revocableInSettings: Boolean
)

/**
 * Inspects strictly the minimal permissions declared by this application.
 * Never requests or probes camera, microphone, location, or gallery access.
 */
object PermissionInspector {

    fun inspectAll(context: Context): List<AppPermissionStatus> {
        val internetGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.INTERNET
        ) == PackageManager.PERMISSION_GRANTED

        val networkStateGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_NETWORK_STATE
        ) == PackageManager.PERMISSION_GRANTED

        val bootGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECEIVE_BOOT_COMPLETED
        ) == PackageManager.PERMISSION_GRANTED

        val notificationsGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        }

        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val isDeviceOwner = dpm?.isDeviceOwnerApp(context.packageName) == true

        return listOf(
            AppPermissionStatus(
                permissionKey = "INTERNET",
                label = "HTTPS Backend & WebView Connectivity",
                granted = internetGranted,
                revocableInSettings = false
            ),
            AppPermissionStatus(
                permissionKey = "ACCESS_NETWORK_STATE",
                label = "Network Connection Monitoring",
                granted = networkStateGranted,
                revocableInSettings = false
            ),
            AppPermissionStatus(
                permissionKey = "RECEIVE_BOOT_COMPLETED",
                label = "Boot State Recovery",
                granted = bootGranted,
                revocableInSettings = false
            ),
            AppPermissionStatus(
                permissionKey = "POST_NOTIFICATIONS",
                label = "Visible Boot Recovery Notification",
                granted = notificationsGranted,
                revocableInSettings = true
            ),
            AppPermissionStatus(
                permissionKey = "DEVICE_OWNER_KIOSK",
                label = "Managed Device Owner Kiosk (Optional)",
                granted = isDeviceOwner,
                revocableInSettings = false
            )
        )
    }

    fun toBackendMap(context: Context): Map<String, Boolean> {
        return inspectAll(context).associate { it.permissionKey to it.granted }
    }

    fun openAppPermissionSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }
}
