package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianDeep = Color(0xFF0B132B)
val ObsidianSurface = Color(0xFF131D3B)
val SlateElevated = Color(0xFF1C2541)
val SlateBorder = Color(0xFF3A506B)
val TealSignal = Color(0xFF5BC0BE)
val TealGlow = Color(0xFF6FFFE9)
val MistWhite = Color(0xFFF8FAFC)
val SlateMuted = Color(0xFF94A3B8)
val AmberWarning = Color(0xFFF59E0B)
val CoralError = Color(0xFFEF4444)
val CoralContainer = Color(0xFF3B151D)
val EmeraldOk = Color(0xFF10B981)

val LightBackground = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightPrimary = Color(0xFF0F766E)
val LightSecondary = Color(0xFF334155)
