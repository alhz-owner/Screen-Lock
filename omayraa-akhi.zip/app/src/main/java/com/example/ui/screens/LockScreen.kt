package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.R
import com.example.device.AppPermissionStatus
import com.example.device.PermissionInspector
import com.example.ui.theme.EmeraldOk

/**
 * Fullscreen user-authorized lock screen.
 * Displays the administrator-configured image without unnecessary visual clutter,
 * alongside a small keyboard icon for PIN input and a separate "How to Unlock" button.
 */
@Composable
fun LockScreen(
    lockImageUrl: String,
    unlockInstructions: String,
    showPinDialog: Boolean,
    enteredPin: String,
    pinError: String?,
    showInstructionsSheet: Boolean,
    recoveryMessage: String?,
    isVerifyingRecovery: Boolean,
    permissions: List<AppPermissionStatus>,
    onOpenPinDialog: () -> Unit,
    onDismissPinDialog: () -> Unit,
    onPinDigit: (String) -> Unit,
    onPinBackspace: () -> Unit,
    onPinClear: () -> Unit,
    onPinSubmit: () -> Unit,
    onOpenInstructions: () -> Unit,
    onDismissInstructions: () -> Unit,
    onVerifyRecoveryCode: (String) -> Unit,
    onOwnerEmergencyExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(enabled = true) {
        when {
            showPinDialog -> onDismissPinDialog()
            showInstructionsSheet -> onDismissInstructions()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Fullscreen administrator-configured wallpaper with bundled fallback
        AsyncImage(
            model = lockImageUrl.takeIf { it.isNotBlank() } ?: R.drawable.img_lock_default,
            placeholder = painterResource(id = R.drawable.img_lock_default),
            error = painterResource(id = R.drawable.img_lock_default),
            contentDescription = stringResource(R.string.cd_lock_wallpaper),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .testTag("lock_background_image")
        )

        // Subtle bottom scrim solely to guarantee button legibility over bright wallpapers
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(140.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))
                    )
                )
        )

        // Bottom safe-area minimal controls: "How to Unlock" + small keyboard icon
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                onClick = onOpenInstructions,
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.84f),
                tonalElevation = 4.dp,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("how_to_unlock_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.HelpOutline,
                        contentDescription = stringResource(R.string.cd_how_to_unlock),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.label_how_to_unlock),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Surface(
                onClick = onOpenPinDialog,
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                tonalElevation = 6.dp,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .size(52.dp)
                    .testTag("open_pin_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Keyboard,
                        contentDescription = stringResource(R.string.cd_open_pin_pad),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    if (showPinDialog) {
        PinEntryDialog(
            enteredPin = enteredPin,
            pinError = pinError,
            onDismiss = onDismissPinDialog,
            onDigit = onPinDigit,
            onBackspace = onPinBackspace,
            onClear = onPinClear,
            onSubmit = onPinSubmit
        )
    }

    if (showInstructionsSheet) {
        UnlockInstructionsDialog(
            unlockInstructions = unlockInstructions,
            recoveryMessage = recoveryMessage,
            isVerifyingRecovery = isVerifyingRecovery,
            permissions = permissions,
            onDismiss = onDismissInstructions,
            onVerifyRecoveryCode = onVerifyRecoveryCode,
            onOwnerEmergencyExit = onOwnerEmergencyExit
        )
    }
}

@Composable
private fun PinEntryDialog(
    enteredPin: String,
    pinError: String?,
    onDismiss: () -> Unit,
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onSubmit: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
            tonalElevation = 8.dp,
            modifier = Modifier
                .widthIn(max = 360.dp)
                .fillMaxWidth()
                .testTag("pin_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.label_enter_pin),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = stringResource(R.string.label_close)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Masked PIN indicators (never displays plaintext digits)
                val dotCount = maxOf(4, enteredPin.length)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("pin_dots_row")
                ) {
                    repeat(dotCount) { index ->
                        val filled = index < enteredPin.length
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(
                                    if (filled) MaterialTheme.colorScheme.primary
                                    else Color.Transparent
                                )
                                .border(
                                    width = 1.5.dp,
                                    color = if (filled) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape
                                )
                        )
                    }
                }

                AnimatedVisibility(visible = !pinError.isNullOrBlank()) {
                    Text(
                        text = pinError.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .testTag("pin_error_text")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                val rows = remember {
                    listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9")
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    rows.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { digit ->
                                PinKeyButton(
                                    label = digit,
                                    onClick = { onDigit(digit) },
                                    modifier = Modifier.testTag("pin_key_$digit")
                                )
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            onClick = onClear,
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .size(64.dp)
                                .testTag("pin_clear_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "CLR",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        PinKeyButton(
                            label = "0",
                            onClick = { onDigit("0") },
                            modifier = Modifier.testTag("pin_key_0")
                        )

                        Surface(
                            onClick = onBackspace,
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .size(64.dp)
                                .testTag("pin_backspace_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Backspace,
                                    contentDescription = stringResource(R.string.cd_backspace),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onSubmit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 50.dp)
                        .testTag("pin_submit_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LockOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(text = stringResource(R.string.label_unlock))
                }
            }
        }
    }
}

@Composable
private fun PinKeyButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 2.dp,
        modifier = modifier.size(64.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun UnlockInstructionsDialog(
    unlockInstructions: String,
    recoveryMessage: String?,
    isVerifyingRecovery: Boolean,
    permissions: List<AppPermissionStatus>,
    onDismiss: () -> Unit,
    onVerifyRecoveryCode: (String) -> Unit,
    onOwnerEmergencyExit: () -> Unit
) {
    val context = LocalContext.current
    var recoveryCodeInput by rememberSaveable { mutableStateOf("") }
    var showEmergencyConfirm by rememberSaveable { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .widthIn(max = 460.dp)
                .fillMaxWidth()
                .testTag("instructions_sheet")
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.label_recovery_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = stringResource(R.string.label_close)
                        )
                    }
                }

                Text(
                    text = unlockInstructions.takeIf { it.isNotBlank() }
                        ?: stringResource(R.string.label_default_unlock_instructions),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("unlock_instructions_text")
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                Text(
                    text = stringResource(R.string.label_emergency_recovery_section),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                OutlinedTextField(
                    value = recoveryCodeInput,
                    onValueChange = { recoveryCodeInput = it },
                    label = { Text(stringResource(R.string.label_recovery_code_hint)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("recovery_code_input")
                )

                AnimatedVisibility(visible = !recoveryMessage.isNullOrBlank()) {
                    Text(
                        text = recoveryMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Button(
                    onClick = { onVerifyRecoveryCode(recoveryCodeInput) },
                    enabled = !isVerifyingRecovery && recoveryCodeInput.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("verify_recovery_button")
                ) {
                    if (isVerifyingRecovery) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text(text = stringResource(R.string.label_verify_recovery_code))
                    }
                }

                OutlinedButton(
                    onClick = { showEmergencyConfirm = true },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("owner_emergency_exit_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WarningAmber,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(text = stringResource(R.string.label_owner_emergency_exit))
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = stringResource(R.string.label_permissions_section),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                permissions.forEach { perm ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = perm.label,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = if (perm.granted) Icons.Rounded.CheckCircle else Icons.Rounded.Close,
                            contentDescription = if (perm.granted) "Granted" else "Denied",
                            tint = if (perm.granted) EmeraldOk else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                TextButton(
                    onClick = { PermissionInspector.openAppPermissionSettings(context) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("manage_permissions_button")
                ) {
                    Text(text = stringResource(R.string.label_manage_permissions))
                }
            }
        }
    }

    if (showEmergencyConfirm) {
        AlertDialog(
            onDismissRequest = { showEmergencyConfirm = false },
            title = { Text(stringResource(R.string.label_owner_emergency_exit_confirm_title)) },
            text = { Text(stringResource(R.string.label_owner_emergency_exit_confirm_body)) },
            confirmButton = {
                Button(
                    onClick = {
                        showEmergencyConfirm = false
                        onOwnerEmergencyExit()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.testTag("confirm_owner_emergency_exit_button")
                ) {
                    Text(stringResource(R.string.label_confirm_exit))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEmergencyConfirm = false }) {
                    Text(stringResource(R.string.label_cancel))
                }
            }
        )
    }
}
