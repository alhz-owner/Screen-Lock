package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ScreenLockRepository
import com.example.data.security.PersistedAppState
import com.example.device.AppPermissionStatus
import com.example.device.PermissionInspector
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ScreenMode {
    LOADING,
    WEBSITE,
    CONNECTION_ERROR,
    LOCKED
}

data class MainUiState(
    val mode: ScreenMode = ScreenMode.LOADING,
    val websiteUrl: String = "",
    val lockImageUrl: String = "",
    val unlockInstructions: String = "",
    val backendApiUrl: String = "",
    val deviceId: String = "",
    val enrollmentStatus: String = "UNREGISTERED",
    val isLocked: Boolean = false,
    val hasPinConfigured: Boolean = false,
    val configVersion: Int = 0,
    val isSyncing: Boolean = false,
    val webPageProgress: Int = 0,
    val errorMessage: String? = null,
    val showPinDialog: Boolean = false,
    val enteredPin: String = "",
    val pinError: String? = null,
    val showInstructionsSheet: Boolean = false,
    val recoveryMessage: String? = null,
    val isVerifyingRecovery: Boolean = false,
    val permissions: List<AppPermissionStatus> = emptyList(),
    val shouldEnterLockTask: Boolean = false,
    val shouldExitLockTask: Boolean = false
)

class MainViewModel(
    application: Application,
    private val repository: ScreenLockRepository
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application,
        ScreenLockRepository(application.applicationContext)
    )

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var pollingJob: Job? = null

    init {
        observePersistedState()
    }

    private fun observePersistedState() {
        viewModelScope.launch {
            repository.stateFlow.collect { persisted ->
                applyPersistedState(persisted)
            }
        }
    }

    fun initialize(fromBootRecovery: Boolean = false) {
        refreshPermissions()
        viewModelScope.launch {
            val snapshot = repository.getSnapshot()
            applyPersistedState(snapshot)
            if (fromBootRecovery) {
                repository.reportBootRecovered(snapshot.isLocked)
            }
            syncNow(initialBoot = true)
            startPeriodicSync()
        }
    }

    fun refreshPermissions() {
        val perms = PermissionInspector.inspectAll(getApplication())
        _uiState.update { it.copy(permissions = perms) }
    }

    fun syncNow(initialBoot: Boolean = false) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true) }
            val effectiveUrl = repository.resolveEffectiveBackendUrl()
            val result = repository.syncWithBackend()
            result.onSuccess { synced ->
                _uiState.update { state ->
                    val nextMode = when {
                        synced.isLocked -> ScreenMode.LOCKED
                        synced.websiteUrl.isNotBlank() -> ScreenMode.WEBSITE
                        else -> ScreenMode.CONNECTION_ERROR
                    }
                    state.copy(
                        mode = nextMode,
                        websiteUrl = synced.websiteUrl,
                        lockImageUrl = synced.lockImageUrl,
                        unlockInstructions = synced.unlockInstructions,
                        backendApiUrl = effectiveUrl,
                        deviceId = synced.deviceId,
                        enrollmentStatus = synced.enrollmentStatus,
                        isLocked = synced.isLocked,
                        hasPinConfigured = synced.pinHash.isNotBlank(),
                        configVersion = synced.configVersion,
                        isSyncing = false,
                        errorMessage = null,
                        shouldEnterLockTask = synced.isLocked,
                        shouldExitLockTask = !synced.isLocked && state.isLocked
                    )
                }
            }.onFailure { err ->
                val cached = repository.getSnapshot()
                _uiState.update { state ->
                    val nextMode = when {
                        cached.isLocked -> ScreenMode.LOCKED
                        cached.websiteUrl.isNotBlank() && !initialBoot -> state.mode
                        cached.websiteUrl.isNotBlank() -> ScreenMode.WEBSITE
                        else -> ScreenMode.CONNECTION_ERROR
                    }
                    state.copy(
                        mode = nextMode,
                        backendApiUrl = effectiveUrl,
                        deviceId = cached.deviceId,
                        isSyncing = false,
                        errorMessage = if (nextMode == ScreenMode.CONNECTION_ERROR) {
                            err.localizedMessage ?: "Unable to connect to backend service."
                        } else {
                            null
                        }
                    )
                }
            }
        }
    }

    fun configureBackend(url: String, enrollmentKey: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, errorMessage = null) }
            val result = repository.configureBackendAndConnect(url, enrollmentKey)
            result.onSuccess { synced ->
                _uiState.update {
                    it.copy(
                        mode = if (synced.isLocked) ScreenMode.LOCKED else ScreenMode.WEBSITE,
                        websiteUrl = synced.websiteUrl,
                        lockImageUrl = synced.lockImageUrl,
                        unlockInstructions = synced.unlockInstructions,
                        backendApiUrl = synced.backendApiUrl,
                        deviceId = synced.deviceId,
                        enrollmentStatus = synced.enrollmentStatus,
                        isLocked = synced.isLocked,
                        hasPinConfigured = synced.pinHash.isNotBlank(),
                        configVersion = synced.configVersion,
                        isSyncing = false,
                        errorMessage = null
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        mode = ScreenMode.CONNECTION_ERROR,
                        isSyncing = false,
                        errorMessage = err.localizedMessage ?: "Failed to connect to backend."
                    )
                }
            }
        }
    }

    fun onWebViewProgress(progress: Int) {
        _uiState.update { it.copy(webPageProgress = progress) }
    }

    fun onWebViewError(description: String) {
        _uiState.update { state ->
            if (state.mode == ScreenMode.LOCKED) {
                state
            } else {
                state.copy(
                    mode = ScreenMode.CONNECTION_ERROR,
                    errorMessage = description
                )
            }
        }
    }

    fun retryWebsiteOrSync() {
        viewModelScope.launch {
            val snapshot = repository.getSnapshot()
            if (snapshot.websiteUrl.isNotBlank()) {
                _uiState.update {
                    it.copy(
                        mode = if (snapshot.isLocked) ScreenMode.LOCKED else ScreenMode.WEBSITE,
                        errorMessage = null
                    )
                }
            }
            syncNow()
        }
    }

    fun activateScreenLock() {
        viewModelScope.launch {
            val updated = repository.activateLock()
            _uiState.update {
                it.copy(
                    mode = ScreenMode.LOCKED,
                    isLocked = true,
                    showPinDialog = false,
                    showInstructionsSheet = false,
                    enteredPin = "",
                    pinError = null,
                    shouldEnterLockTask = true,
                    shouldExitLockTask = false,
                    hasPinConfigured = updated.pinHash.isNotBlank()
                )
            }
        }
    }

    fun openPinDialog() {
        _uiState.update {
            it.copy(
                showPinDialog = true,
                enteredPin = "",
                pinError = null
            )
        }
    }

    fun dismissPinDialog() {
        _uiState.update {
            it.copy(
                showPinDialog = false,
                enteredPin = "",
                pinError = null
            )
        }
    }

    fun appendPinDigit(digit: String) {
        _uiState.update { state ->
            if (state.enteredPin.length >= 12) return@update state
            state.copy(enteredPin = state.enteredPin + digit, pinError = null)
        }
    }

    fun backspacePin() {
        _uiState.update { state ->
            if (state.enteredPin.isEmpty()) return@update state
            state.copy(enteredPin = state.enteredPin.dropLast(1), pinError = null)
        }
    }

    fun clearPin() {
        _uiState.update { it.copy(enteredPin = "", pinError = null) }
    }

    fun submitPin() {
        val pin = _uiState.value.enteredPin
        if (pin.length < 4) {
            _uiState.update { it.copy(pinError = "Enter at least 4 digits") }
            return
        }
        viewModelScope.launch {
            val valid = repository.verifyPinAndUnlock(pin)
            if (valid) {
                _uiState.update { state ->
                    state.copy(
                        mode = if (state.websiteUrl.isNotBlank()) ScreenMode.WEBSITE else ScreenMode.CONNECTION_ERROR,
                        isLocked = false,
                        showPinDialog = false,
                        showInstructionsSheet = false,
                        enteredPin = "",
                        pinError = null,
                        shouldEnterLockTask = false,
                        shouldExitLockTask = true
                    )
                }
            } else {
                // Allow repeated attempts without artificial waiting period
                _uiState.update {
                    it.copy(
                        enteredPin = "",
                        pinError = "Incorrect PIN. Try again."
                    )
                }
            }
        }
    }

    fun openInstructionsSheet() {
        refreshPermissions()
        _uiState.update {
            it.copy(
                showInstructionsSheet = true,
                recoveryMessage = null
            )
        }
    }

    fun dismissInstructionsSheet() {
        _uiState.update {
            it.copy(
                showInstructionsSheet = false,
                recoveryMessage = null
            )
        }
    }

    fun verifyEmergencyRecoveryCode(code: String) {
        if (code.isBlank()) {
            _uiState.update { it.copy(recoveryMessage = "Enter the 8-character recovery code.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isVerifyingRecovery = true, recoveryMessage = null) }
            val result = repository.verifyEmergencyRecoveryCode(code)
            result.onSuccess { valid ->
                if (valid) {
                    _uiState.update { state ->
                        state.copy(
                            mode = if (state.websiteUrl.isNotBlank()) ScreenMode.WEBSITE else ScreenMode.CONNECTION_ERROR,
                            isLocked = false,
                            showInstructionsSheet = false,
                            showPinDialog = false,
                            isVerifyingRecovery = false,
                            recoveryMessage = null,
                            shouldEnterLockTask = false,
                            shouldExitLockTask = true
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isVerifyingRecovery = false,
                            recoveryMessage = "Invalid or expired recovery code."
                        )
                    }
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isVerifyingRecovery = false,
                        recoveryMessage = err.localizedMessage ?: "Verification failed."
                    )
                }
            }
        }
    }

    fun performOwnerEmergencyExit() {
        viewModelScope.launch {
            repository.performOwnerEmergencyExit()
            _uiState.update { state ->
                state.copy(
                    mode = if (state.websiteUrl.isNotBlank()) ScreenMode.WEBSITE else ScreenMode.CONNECTION_ERROR,
                    isLocked = false,
                    showInstructionsSheet = false,
                    showPinDialog = false,
                    enteredPin = "",
                    pinError = null,
                    shouldEnterLockTask = false,
                    shouldExitLockTask = true
                )
            }
        }
    }

    fun consumeLockTaskFlags() {
        _uiState.update { it.copy(shouldEnterLockTask = false, shouldExitLockTask = false) }
    }

    private fun applyPersistedState(persisted: PersistedAppState) {
        _uiState.update { state ->
            val resolvedMode = when {
                persisted.isLocked -> ScreenMode.LOCKED
                persisted.websiteUrl.isNotBlank() && state.mode == ScreenMode.LOADING -> ScreenMode.WEBSITE
                else -> state.mode
            }
            state.copy(
                mode = resolvedMode,
                websiteUrl = persisted.websiteUrl,
                lockImageUrl = persisted.lockImageUrl,
                unlockInstructions = persisted.unlockInstructions,
                backendApiUrl = persisted.backendApiUrl,
                deviceId = persisted.deviceId,
                enrollmentStatus = persisted.enrollmentStatus,
                isLocked = persisted.isLocked,
                hasPinConfigured = persisted.pinHash.isNotBlank(),
                configVersion = persisted.configVersion
            )
        }
    }

    private fun startPeriodicSync() {
        if (pollingJob?.isActive == true) return
        pollingJob = viewModelScope.launch {
            while (isActive) {
                delay(30_000L)
                syncNow()
            }
        }
    }
}
