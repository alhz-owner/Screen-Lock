package com.example.data.security

import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Constant-time PBKDF2-HMAC-SHA256 PIN hashing and verification.
 * Wire format shared with the Node.js backend:
 *   pbkdf2_sha256$<iterations>$<saltHex>$<derivedKeyHex>
 *
 * Plaintext PIN values are never logged or persisted.
 */
object PinHasher {
    private const val PREFIX = "pbkdf2_sha256"
    private const val DEFAULT_ITERATIONS = 100_000
    private const val SALT_BYTES = 16
    private const val KEY_BYTES = 32

    fun hashPin(pin: String, iterations: Int = DEFAULT_ITERATIONS): String {
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val derived = pbkdf2HmacSha256(pin.toByteArray(Charsets.UTF_8), salt, iterations, KEY_BYTES)
        return "$PREFIX$$iterations$${salt.toHex()}$${derived.toHex()}"
    }

    fun verifyPin(pin: String, encodedHash: String): Boolean {
        if (pin.isEmpty() || encodedHash.isBlank()) return false
        val parts = encodedHash.split("$")
        if (parts.size != 4 || parts[0] != PREFIX) return false
        val iterations = parts[1].toIntOrNull() ?: return false
        if (iterations < 10_000) return false
        val salt = hexToBytes(parts[2]) ?: return false
        val expected = hexToBytes(parts[3]) ?: return false
        if (expected.isEmpty()) return false

        val actual = pbkdf2HmacSha256(
            password = pin.toByteArray(Charsets.UTF_8),
            salt = salt,
            iterations = iterations,
            keyLengthBytes = expected.size
        )
        return MessageDigest.isEqual(actual, expected)
    }

    private fun pbkdf2HmacSha256(
        password: ByteArray,
        salt: ByteArray,
        iterations: Int,
        keyLengthBytes: Int
    ): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(password, "HmacSHA256"))
        val hashLen = mac.macLength
        val blockCount = (keyLengthBytes + hashLen - 1) / hashLen
        val output = ByteArray(blockCount * hashLen)

        for (blockIndex in 1..blockCount) {
            val blockInput = ByteBuffer.allocate(salt.size + 4)
                .put(salt)
                .putInt(blockIndex)
                .array()
            var u = mac.doFinal(blockInput)
            val t = u.copyOf()
            for (iter in 2..iterations) {
                u = mac.doFinal(u)
                for (i in t.indices) {
                    t[i] = (t[i].toInt() xor u[i].toInt()).toByte()
                }
            }
            System.arraycopy(t, 0, output, (blockIndex - 1) * hashLen, hashLen)
        }
        return output.copyOf(keyLengthBytes)
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun hexToBytes(hex: String): ByteArray? {
        if (hex.length % 2 != 0) return null
        return try {
            ByteArray(hex.length / 2) { index ->
                hex.substring(index * 2, index * 2 + 2).toInt(16).toByte()
            }
        } catch (_: NumberFormatException) {
            null
        }
    }
}
