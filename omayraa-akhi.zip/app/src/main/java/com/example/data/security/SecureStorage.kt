package com.example.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.screenLockDataStore by preferencesDataStore(name = "screen_lock_secure_prefs")

data class PersistedAppState(
    val backendApiUrl: String,
    val deviceId: String,
    val deviceToken: String,
    val websiteUrl: String,
    val lockImageUrl: String,
    val unlockInstructions: String,
    val configVersion: Int,
    val pinHash: String,
    val isLocked: Boolean,
    val bootRecoveryEnabled: Boolean,
    val enrollmentStatus: String
)

/**
 * Persists application and lock configuration in DataStore, encrypting sensitive fields
 * (deviceToken, pinHash) with an AES-256-GCM key backed by AndroidKeyStore.
 * Falls back cleanly in JVM/Robolectric tests where AndroidKeyStore is absent.
 */
class SecureStorage(private val context: Context) {

    private object Keys {
        val BACKEND_API_URL = stringPreferencesKey("backend_api_url")
        val DEVICE_ID = stringPreferencesKey("device_id")
        val DEVICE_TOKEN_ENC = stringPreferencesKey("device_token_enc")
        val WEBSITE_URL = stringPreferencesKey("website_url")
        val LOCK_IMAGE_URL = stringPreferencesKey("lock_image_url")
        val UNLOCK_INSTRUCTIONS = stringPreferencesKey("unlock_instructions")
        val CONFIG_VERSION = intPreferencesKey("config_version")
        val PIN_HASH_ENC = stringPreferencesKey("pin_hash_enc")
        val IS_LOCKED = booleanPreferencesKey("is_locked")
        val BOOT_RECOVERY_ENABLED = booleanPreferencesKey("boot_recovery_enabled")
        val ENROLLMENT_STATUS = stringPreferencesKey("enrollment_status")
    }

    val stateFlow: Flow<PersistedAppState> = context.screenLockDataStore.data.map { prefs ->
        mapPreferences(prefs)
    }

    suspend fun getSnapshot(): PersistedAppState {
        val current = context.screenLockDataStore.data.first()
        var mapped = mapPreferences(current)
        if (mapped.deviceId.isBlank()) {
            val generated = "android-${UUID.randomUUID().toString().take(12)}"
            context.screenLockDataStore.edit { prefs ->
                prefs[Keys.DEVICE_ID] = generated
            }
            mapped = mapped.copy(deviceId = generated)
        }
        return mapped
    }

    suspend fun saveBackendUrl(url: String) {
        val normalized = normalizeUrl(url)
        context.screenLockDataStore.edit { prefs ->
            prefs[Keys.BACKEND_API_URL] = normalized
        }
    }

    suspend fun saveDeviceToken(token: String) {
        val encrypted = encryptValue(token)
        context.screenLockDataStore.edit { prefs ->
            prefs[Keys.DEVICE_TOKEN_ENC] = encrypted
        }
    }

    suspend fun clearDeviceToken() {
        context.screenLockDataStore.edit { prefs ->
            prefs.remove(Keys.DEVICE_TOKEN_ENC)
        }
    }

    suspend fun saveSyncedConfig(
        websiteUrl: String,
        lockImageUrl: String,
        unlockInstructions: String,
        configVersion: Int,
        pinHash: String,
        isLocked: Boolean?,
        enrollmentStatus: String
    ) {
        val encryptedPinHash = if (pinHash.isNotBlank()) encryptValue(pinHash) else null
        context.screenLockDataStore.edit { prefs ->
            if (websiteUrl.isNotBlank()) prefs[Keys.WEBSITE_URL] = websiteUrl
            prefs[Keys.LOCK_IMAGE_URL] = lockImageUrl
            if (unlockInstructions.isNotBlank()) prefs[Keys.UNLOCK_INSTRUCTIONS] = unlockInstructions
            prefs[Keys.CONFIG_VERSION] = configVersion
            if (encryptedPinHash != null) prefs[Keys.PIN_HASH_ENC] = encryptedPinHash
            if (isLocked != null) prefs[Keys.IS_LOCKED] = isLocked
            if (enrollmentStatus.isNotBlank()) prefs[Keys.ENROLLMENT_STATUS] = enrollmentStatus
        }
    }

    suspend fun setLockedState(locked: Boolean) {
        context.screenLockDataStore.edit { prefs ->
            prefs[Keys.IS_LOCKED] = locked
        }
    }

    suspend fun setBootRecoveryEnabled(enabled: Boolean) {
        context.screenLockDataStore.edit { prefs ->
            prefs[Keys.BOOT_RECOVERY_ENABLED] = enabled
        }
    }

    private fun mapPreferences(prefs: Preferences): PersistedAppState {
        return PersistedAppState(
            backendApiUrl = prefs[Keys.BACKEND_API_URL].orEmpty(),
            deviceId = prefs[Keys.DEVICE_ID].orEmpty(),
            deviceToken = decryptValue(prefs[Keys.DEVICE_TOKEN_ENC].orEmpty()),
            websiteUrl = prefs[Keys.WEBSITE_URL].orEmpty(),
            lockImageUrl = prefs[Keys.LOCK_IMAGE_URL].orEmpty(),
            unlockInstructions = prefs[Keys.UNLOCK_INSTRUCTIONS].orEmpty(),
            configVersion = prefs[Keys.CONFIG_VERSION] ?: 0,
            pinHash = decryptValue(prefs[Keys.PIN_HASH_ENC].orEmpty()),
            isLocked = prefs[Keys.IS_LOCKED] ?: false,
            bootRecoveryEnabled = prefs[Keys.BOOT_RECOVERY_ENABLED] ?: true,
            enrollmentStatus = prefs[Keys.ENROLLMENT_STATUS] ?: "UNREGISTERED"
        )
    }

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim().trimEnd('/')
        return if (trimmed.isNotEmpty()) "$trimmed/" else ""
    }

    private fun encryptValue(plaintext: String): String {
        if (plaintext.isEmpty()) return ""
        return runCatching {
            val key = getOrCreateAesKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val cipherText = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
            val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
            val dataB64 = Base64.encodeToString(cipherText, Base64.NO_WRAP)
            "aes:$ivB64:$dataB64"
        }.getOrElse {
            // JVM/Robolectric fallback where AndroidKeyStore provider is unavailable
            "b64:" + Base64.encodeToString(plaintext.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    private fun decryptValue(encoded: String): String {
        if (encoded.isEmpty()) return ""
        if (encoded.startsWith("b64:")) {
            return runCatching {
                String(Base64.decode(encoded.removePrefix("b64:"), Base64.NO_WRAP), Charsets.UTF_8)
            }.getOrDefault("")
        }
        if (!encoded.startsWith("aes:")) return ""
        return runCatching {
            val parts = encoded.split(":")
            if (parts.size != 3) return ""
            val iv = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipherText = Base64.decode(parts[2], Base64.NO_WRAP)
            val key = getOrCreateAesKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        }.getOrDefault("")
    }

    private fun getOrCreateAesKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = (keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.secretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "omayraa_akhi_secure_storage_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
