package com.example.data.repository

import android.content.Context
import android.os.Build
import com.example.BuildConfig
import com.example.data.remote.ActivityEventRequest
import com.example.data.remote.BackendApiService
import com.example.data.remote.BackendClientProvider
import com.example.data.remote.DeviceRegisterRequest
import com.example.data.remote.HeartbeatRequest
import com.example.data.remote.RecoveryVerifyRequest
import com.example.data.security.PersistedAppState
import com.example.data.security.PinHasher
import com.example.data.security.SecureStorage
import com.example.device.PermissionInspector
import kotlinx.coroutines.flow.Flow
import retrofit2.HttpException

class ScreenLockRepository(
    private val context: Context,
    private val storage: SecureStorage = SecureStorage(context)
) {

    val stateFlow: Flow<PersistedAppState> = storage.stateFlow

    suspend fun getSnapshot(): PersistedAppState = storage.getSnapshot()

    suspend fun resolveEffectiveBackendUrl(): String {
        val persisted = storage.getSnapshot().backendApiUrl
        return when {
            persisted.isNotBlank() -> persisted
            BuildConfig.BACKEND_API_URL.isNotBlank() -> BuildConfig.BACKEND_API_URL
            else -> ""
        }
    }

    suspend fun configureBackendAndConnect(
        backendUrl: String,
        enrollmentKey: String? = null
    ): Result<PersistedAppState> {
        return runCatching {
            val normalized = BackendClientProvider.normalizeBaseUrl(backendUrl)
            storage.saveBackendUrl(normalized)
            storage.clearDeviceToken()
            syncWithBackend(enrollmentKey = enrollmentKey?.trim()?.takeIf { it.isNotEmpty() }).getOrThrow()
        }
    }

    suspend fun syncWithBackend(enrollmentKey: String? = null): Result<PersistedAppState> {
        return runCatching {
            val snapshot = storage.getSnapshot()
            val baseUrl = resolveEffectiveBackendUrl()
            require(baseUrl.isNotBlank()) { "Backend API URL is not configured." }

            val service = createApiService(baseUrl, snapshot)
            val permissionsMap = PermissionInspector.toBackendMap(context)

            if (snapshot.deviceToken.isBlank()) {
                val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }
                val reg = service.registerDevice(
                    DeviceRegisterRequest(
                        deviceId = snapshot.deviceId,
                        deviceName = deviceName,
                        enrollmentKey = enrollmentKey,
                        permissions = permissionsMap
                    )
                )
                storage.saveDeviceToken(reg.deviceToken)
                storage.saveSyncedConfig(
                    websiteUrl = reg.config.websiteUrl,
                    lockImageUrl = resolveMediaUrl(baseUrl, reg.config.lockImageUrl),
                    unlockInstructions = reg.config.unlockInstructions,
                    configVersion = reg.config.configurationVersion,
                    pinHash = reg.config.pinHash,
                    isLocked = reg.lockStatus.equals("LOCKED", ignoreCase = true),
                    enrollmentStatus = reg.enrollmentStatus
                )
            } else {
                val sync = try {
                    service.syncDevice(snapshot.deviceId)
                } catch (httpEx: HttpException) {
                    if (httpEx.code() == 401 || httpEx.code() == 404) {
                        storage.clearDeviceToken()
                        val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }
                        val reg = service.registerDevice(
                            DeviceRegisterRequest(
                                deviceId = snapshot.deviceId,
                                deviceName = deviceName,
                                enrollmentKey = enrollmentKey,
                                permissions = permissionsMap
                            )
                        )
                        storage.saveDeviceToken(reg.deviceToken)
                        storage.saveSyncedConfig(
                            websiteUrl = reg.config.websiteUrl,
                            lockImageUrl = resolveMediaUrl(baseUrl, reg.config.lockImageUrl),
                            unlockInstructions = reg.config.unlockInstructions,
                            configVersion = reg.config.configurationVersion,
                            pinHash = reg.config.pinHash,
                            isLocked = reg.lockStatus.equals("LOCKED", ignoreCase = true),
                            enrollmentStatus = reg.enrollmentStatus
                        )
                        return@runCatching storage.getSnapshot()
                    } else {
                        throw httpEx
                    }
                }

                storage.saveSyncedConfig(
                    websiteUrl = sync.config.websiteUrl,
                    lockImageUrl = resolveMediaUrl(baseUrl, sync.config.lockImageUrl),
                    unlockInstructions = sync.config.unlockInstructions,
                    configVersion = sync.config.configurationVersion,
                    pinHash = sync.config.pinHash,
                    isLocked = if (sync.lockStatus.equals("LOCKED", ignoreCase = true)) true else null,
                    enrollmentStatus = sync.enrollmentStatus
                )

                // Send updated permission status and online heartbeat
                runCatching {
                    val refreshed = storage.getSnapshot()
                    val authedService = createApiService(baseUrl, refreshed)
                    authedService.sendHeartbeat(
                        deviceId = refreshed.deviceId,
                        body = HeartbeatRequest(
                            connectionStatus = "ONLINE",
                            lockStatus = if (refreshed.isLocked) "LOCKED" else "UNLOCKED",
                            permissions = permissionsMap
                        )
                    )
                }
            }
            storage.getSnapshot()
        }
    }

    suspend fun activateLock(): PersistedAppState {
        storage.setLockedState(true)
        val snapshot = storage.getSnapshot()
        reportEventSafe(snapshot, "LOCKED", "User authorized screen lock activation")
        return snapshot
    }

    suspend fun verifyPinAndUnlock(enteredPin: String): Boolean {
        val snapshot = storage.getSnapshot()
        if (snapshot.pinHash.isBlank()) return false
        val valid = PinHasher.verifyPin(enteredPin, snapshot.pinHash)
        if (valid) {
            storage.setLockedState(false)
            reportEventSafe(snapshot, "UNLOCKED", "PIN verified locally")
        } else {
            reportEventSafe(snapshot, "UNLOCK_FAILED", "Invalid PIN attempt")
        }
        return valid
    }

    suspend fun verifyEmergencyRecoveryCode(code: String): Result<Boolean> {
        return runCatching {
            val snapshot = storage.getSnapshot()
            val baseUrl = resolveEffectiveBackendUrl()
            require(baseUrl.isNotBlank() && snapshot.deviceToken.isNotBlank()) {
                "Backend connection unavailable for code verification."
            }
            val service = createApiService(baseUrl, snapshot)
            val response = service.verifyRecoveryCode(
                deviceId = snapshot.deviceId,
                body = RecoveryVerifyRequest(recoveryCode = code.trim())
            )
            if (response.valid) {
                storage.setLockedState(false)
                reportEventSafe(snapshot, "EMERGENCY_RECOVERY", "Unlocked with admin recovery code")
            }
            response.valid
        }
    }

    suspend fun performOwnerEmergencyExit() {
        storage.setLockedState(false)
        val snapshot = storage.getSnapshot()
        reportEventSafe(snapshot, "EMERGENCY_OWNER_EXIT", "Device owner executed local emergency exit")
    }

    suspend fun reportBootRecovered(wasLocked: Boolean) {
        val snapshot = storage.getSnapshot()
        reportEventSafe(
            snapshot,
            "BOOT_RECOVERED",
            if (wasLocked) "Restored locked kiosk session after reboot" else "Restored website session after reboot"
        )
    }

    private suspend fun reportEventSafe(
        snapshot: PersistedAppState,
        eventType: String,
        details: String
    ) {
        val baseUrl = resolveEffectiveBackendUrl()
        if (baseUrl.isBlank() || snapshot.deviceToken.isBlank()) return
        runCatching {
            val service = createApiService(baseUrl, snapshot)
            service.reportEvent(
                deviceId = snapshot.deviceId,
                body = ActivityEventRequest(eventType = eventType, details = details)
            )
            service.sendHeartbeat(
                deviceId = snapshot.deviceId,
                body = HeartbeatRequest(
                    connectionStatus = "ONLINE",
                    lockStatus = if (snapshot.isLocked) "LOCKED" else "UNLOCKED",
                    permissions = PermissionInspector.toBackendMap(context)
                )
            )
        }
    }

    private fun createApiService(baseUrl: String, snapshot: PersistedAppState): BackendApiService {
        return BackendClientProvider.createService(
            baseUrl = baseUrl,
            tokenProvider = { snapshot.deviceToken },
            deviceIdProvider = { snapshot.deviceId }
        )
    }

    private fun resolveMediaUrl(baseUrl: String, imageUrl: String): String {
        val trimmed = imageUrl.trim()
        if (trimmed.isEmpty()) return ""
        if (trimmed.startsWith("https://") || trimmed.startsWith("http://")) return trimmed
        val cleanBase = baseUrl.trimEnd('/')
        val cleanPath = if (trimmed.startsWith("/")) trimmed else "/$trimmed"
        return "$cleanBase$cleanPath"
    }
}
