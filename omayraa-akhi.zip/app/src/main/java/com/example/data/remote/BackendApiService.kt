package com.example.data.remote

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface BackendApiService {

    @POST("api/devices/register")
    suspend fun registerDevice(
        @Body body: DeviceRegisterRequest
    ): DeviceRegisterResponse

    @GET("api/devices/{deviceId}/sync")
    suspend fun syncDevice(
        @Path("deviceId") deviceId: String
    ): DeviceSyncResponse

    @POST("api/devices/{deviceId}/heartbeat")
    suspend fun sendHeartbeat(
        @Path("deviceId") deviceId: String,
        @Body body: HeartbeatRequest
    ): ApiStatusResponse

    @POST("api/devices/{deviceId}/events")
    suspend fun reportEvent(
        @Path("deviceId") deviceId: String,
        @Body body: ActivityEventRequest
    ): ApiStatusResponse

    @POST("api/devices/{deviceId}/recovery/verify")
    suspend fun verifyRecoveryCode(
        @Path("deviceId") deviceId: String,
        @Body body: RecoveryVerifyRequest
    ): RecoveryVerifyResponse
}
