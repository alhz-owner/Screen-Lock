package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class DeviceRegisterRequest(
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_name") val deviceName: String,
    @Json(name = "enrollment_key") val enrollmentKey: String? = null,
    @Json(name = "permissions") val permissions: Map<String, Boolean>
)

@JsonClass(generateAdapter = true)
data class AppConfigurationDto(
    @Json(name = "website_url") val websiteUrl: String,
    @Json(name = "lock_image_url") val lockImageUrl: String = "",
    @Json(name = "unlock_instructions") val unlockInstructions: String = "",
    @Json(name = "configuration_version") val configurationVersion: Int = 1,
    @Json(name = "pin_hash") val pinHash: String = "",
    @Json(name = "updated_at") val updatedAt: String = ""
)

@JsonClass(generateAdapter = true)
data class DeviceRegisterResponse(
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_token") val deviceToken: String,
    @Json(name = "enrollment_status") val enrollmentStatus: String,
    @Json(name = "lock_status") val lockStatus: String,
    @Json(name = "config") val config: AppConfigurationDto
)

@JsonClass(generateAdapter = true)
data class DeviceSyncResponse(
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "enrollment_status") val enrollmentStatus: String,
    @Json(name = "lock_status") val lockStatus: String,
    @Json(name = "config") val config: AppConfigurationDto
)

@JsonClass(generateAdapter = true)
data class HeartbeatRequest(
    @Json(name = "connection_status") val connectionStatus: String,
    @Json(name = "lock_status") val lockStatus: String,
    @Json(name = "permissions") val permissions: Map<String, Boolean>
)

@JsonClass(generateAdapter = true)
data class ActivityEventRequest(
    @Json(name = "event_type") val eventType: String,
    @Json(name = "details") val details: String? = null
)

@JsonClass(generateAdapter = true)
data class RecoveryVerifyRequest(
    @Json(name = "recovery_code") val recoveryCode: String
)

@JsonClass(generateAdapter = true)
data class RecoveryVerifyResponse(
    @Json(name = "valid") val valid: Boolean,
    @Json(name = "message") val message: String = ""
)

@JsonClass(generateAdapter = true)
data class ApiStatusResponse(
    @Json(name = "ok") val ok: Boolean,
    @Json(name = "message") val message: String = ""
)
