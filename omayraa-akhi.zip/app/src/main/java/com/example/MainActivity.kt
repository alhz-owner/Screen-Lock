package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.device.KioskController
import com.example.device.ScreenLockNotificationManager
import com.example.ui.MainViewModel
import com.example.ui.ScreenMode
import com.example.ui.screens.ConnectionErrorScreen
import com.example.ui.screens.LockScreen
import com.example.ui.screens.WebsiteWebViewScreen
import com.example.ui.theme.ScreenLockTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val fromBootRecovery = intent?.getBooleanExtra(
            ScreenLockNotificationManager.EXTRA_BOOT_RECOVERY,
            false
        ) == true
        viewModel.initialize(fromBootRecovery = fromBootRecovery)

        setContent {
            ScreenLockTheme(darkTheme = true, dynamicColor = false) {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                // Request optional POST_NOTIFICATIONS runtime permission on Android 13+
                // strictly for visible boot recovery notification; app continues seamlessly if denied.
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { _ ->
                    viewModel.refreshPermissions()
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val granted = ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!granted) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                LaunchedEffect(uiState.shouldEnterLockTask, uiState.shouldExitLockTask) {
                    if (uiState.shouldEnterLockTask) {
                        KioskController.enterLockTask(this@MainActivity)
                        viewModel.consumeLockTaskFlags()
                    } else if (uiState.shouldExitLockTask) {
                        KioskController.exitLockTask(this@MainActivity)
                        viewModel.consumeLockTaskFlags()
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    when (uiState.mode) {
                        ScreenMode.LOADING -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        ScreenMode.WEBSITE -> {
                            WebsiteWebViewScreen(
                                websiteUrl = uiState.websiteUrl,
                                progress = uiState.webPageProgress,
                                onProgressChanged = viewModel::onWebViewProgress,
                                onLoadError = viewModel::onWebViewError,
                                onActivateLock = viewModel::activateScreenLock
                            )
                        }

                        ScreenMode.CONNECTION_ERROR -> {
                            ConnectionErrorScreen(
                                currentBackendUrl = uiState.backendApiUrl,
                                deviceId = uiState.deviceId,
                                errorMessage = uiState.errorMessage,
                                isSyncing = uiState.isSyncing,
                                onRetry = viewModel::retryWebsiteOrSync,
                                onSaveBackendConfig = viewModel::configureBackend
                            )
                        }

                        ScreenMode.LOCKED -> {
                            LockScreen(
                                lockImageUrl = uiState.lockImageUrl,
                                unlockInstructions = uiState.unlockInstructions,
                                showPinDialog = uiState.showPinDialog,
                                enteredPin = uiState.enteredPin,
                                pinError = uiState.pinError,
                                showInstructionsSheet = uiState.showInstructionsSheet,
                                recoveryMessage = uiState.recoveryMessage,
                                isVerifyingRecovery = uiState.isVerifyingRecovery,
                                permissions = uiState.permissions,
                                onOpenPinDialog = viewModel::openPinDialog,
                                onDismissPinDialog = viewModel::dismissPinDialog,
                                onPinDigit = viewModel::appendPinDigit,
                                onPinBackspace = viewModel::backspacePin,
                                onPinClear = viewModel::clearPin,
                                onPinSubmit = viewModel::submitPin,
                                onOpenInstructions = viewModel::openInstructionsSheet,
                                onDismissInstructions = viewModel::dismissInstructionsSheet,
                                onVerifyRecoveryCode = viewModel::verifyEmergencyRecoveryCode,
                                onOwnerEmergencyExit = viewModel::performOwnerEmergencyExit
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissions()
    }
}
