package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.device.PermissionInspector
import com.example.ui.screens.ConnectionErrorScreen
import com.example.ui.screens.LockScreen
import com.example.ui.theme.ScreenLockTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `app name matches OmayRaa-Akhi and excludes restricted permissions`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("OmayRaa-Akhi", appName)

        val keys = PermissionInspector.inspectAll(context).map { it.permissionKey }
        assertTrue(keys.contains("INTERNET"))
        assertFalse(keys.contains("CAMERA"))
        assertFalse(keys.contains("RECORD_AUDIO"))
    }

    @Test
    fun `lock screen displays keyboard icon and how to unlock button`() {
        var pinOpened = false
        var instructionsOpened = false

        composeTestRule.setContent {
            ScreenLockTheme {
                LockScreen(
                    lockImageUrl = "",
                    unlockInstructions = "Contact admin for PIN",
                    showPinDialog = false,
                    enteredPin = "",
                    pinError = null,
                    showInstructionsSheet = false,
                    recoveryMessage = null,
                    isVerifyingRecovery = false,
                    permissions = emptyList(),
                    onOpenPinDialog = { pinOpened = true },
                    onDismissPinDialog = {},
                    onPinDigit = {},
                    onPinBackspace = {},
                    onPinClear = {},
                    onPinSubmit = {},
                    onOpenInstructions = { instructionsOpened = true },
                    onDismissInstructions = {},
                    onVerifyRecoveryCode = {},
                    onOwnerEmergencyExit = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("open_pin_button").assertIsDisplayed().performClick()
        composeTestRule.onNodeWithTag("how_to_unlock_button").assertIsDisplayed().performClick()

        assertTrue(pinOpened)
        assertTrue(instructionsOpened)
    }

    @Test
    fun `connection error screen exposes retry action`() {
        var retried = false

        composeTestRule.setContent {
            ScreenLockTheme {
                ConnectionErrorScreen(
                    currentBackendUrl = "",
                    deviceId = "android-test123",
                    errorMessage = "Offline",
                    isSyncing = false,
                    onRetry = { retried = true },
                    onSaveBackendConfig = { _, _ -> }
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("retry_connection_button").assertIsDisplayed().performClick()
        composeTestRule.onNodeWithText("Offline").assertIsDisplayed()
        assertTrue(retried)
    }
}
