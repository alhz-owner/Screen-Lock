package com.example

import com.example.data.security.PinHasher
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PinHasherTest {

    @Test
    fun `hashPin produces pbkdf2_sha256 format and verifies matching pin`() {
        val encoded = PinHasher.hashPin("4829", iterations = 10_000)
        assertTrue(encoded.startsWith("pbkdf2_sha256\$10000\$"))
        assertTrue(PinHasher.verifyPin("4829", encoded))
        assertFalse(PinHasher.verifyPin("0000", encoded))
        assertFalse(PinHasher.verifyPin("", encoded))
    }

    @Test
    fun `verifyPin rejects malformed or weak iteration hashes`() {
        assertFalse(PinHasher.verifyPin("1234", "plaintext_1234"))
        assertFalse(PinHasher.verifyPin("1234", "pbkdf2_sha256\$100\$aabb\$ccdd"))
        assertFalse(PinHasher.verifyPin("1234", ""))
    }
}
